package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.ListAlt
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TrackChanges
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarDuration
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.parser.BanglaUtils
import com.example.ui.screens.BazarModeDialog
import com.example.ui.screens.EditTransactionSheet
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.InsightsScreen
import com.example.ui.screens.PasteSmsDialog
import com.example.ui.screens.PinLockScreen
import com.example.ui.screens.PlanScreen
import com.example.ui.screens.ReviewParsedSheet
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.WalletActionDialog
import com.example.ui.screens.WalletScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.ExpenseViewModel
import com.example.util.configureAppCheck

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Configure App Check with launch intent before any UI or Firebase operations
        configureAppCheck(this, intent)
        enableEdgeToEdge()
        setContent {
            val expenseViewModel: ExpenseViewModel = viewModel()
            val themeMode by expenseViewModel.prefs.theme.collectAsState()
            val accentColor by expenseViewModel.prefs.accent.collectAsState()

            MyApplicationTheme(appTheme = themeMode, accent = accentColor) {
                ExpenseApp(viewModel = expenseViewModel)
            }
        }
    }
}

data class NavItem(
    val route: String,
    val icon: ImageVector,
    val label: String
)

@Composable
fun ExpenseApp(viewModel: ExpenseViewModel) {
    val isLocked by viewModel.isLocked.collectAsState()
    val currentScreen by viewModel.currentScreen.collectAsState()
    val isBangla = viewModel.prefs.language.collectAsState().value == "bn"
    val toastMessage by viewModel.toastMessage.collectAsState()

    val pendingReview by viewModel.pendingReview.collectAsState()
    val isBazarModeOpen by viewModel.isBazarModeOpen.collectAsState()
    val isPasteSmsOpen by viewModel.isPasteSmsOpen.collectAsState()
    val editingTx by viewModel.editingTransaction.collectAsState()
    val walletAction by viewModel.walletActionSheet.collectAsState()
    val wallets by viewModel.prefs.wallets.collectAsState()

    var showImportCsvDialog by remember { mutableStateOf(false) }
    var csvInputText by remember { mutableStateOf("") }

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(toastMessage) {
        val msg = toastMessage
        if (msg != null) {
            val result = snackbarHostState.showSnackbar(
                message = msg,
                actionLabel = "Undo",
                duration = SnackbarDuration.Short
            )
            if (result == SnackbarResult.ActionPerformed) {
                viewModel.triggerUndo()
            }
            viewModel.clearToast()
        }
    }

    // Predictive back / BackHandler
    BackHandler(enabled = !isLocked && currentScreen != "home") {
        if (currentScreen == "plan" && viewModel.activeTourId.value != null) {
            viewModel.closeTourDetail()
        } else {
            viewModel.setScreen("home")
        }
    }

    if (isLocked) {
        PinLockScreen(onUnlock = { pin -> viewModel.unlockApp(pin) })
        return
    }

    val navItems = listOf(
        NavItem("home", Icons.Default.Home, BanglaUtils.tr("Home", isBangla)),
        NavItem("wallet", Icons.Default.AccountBalanceWallet, BanglaUtils.tr("Wallets", isBangla)),
        NavItem("history", Icons.Default.ReceiptLong, BanglaUtils.tr("History", isBangla)),
        NavItem("plan", Icons.Default.TrackChanges, BanglaUtils.tr("Plan", isBangla)),
        NavItem("insights", Icons.Default.Insights, BanglaUtils.tr("Insights", isBangla)),
        NavItem("settings", Icons.Default.Settings, BanglaUtils.tr("Settings", isBangla))
    )

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            NavigationBar(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("main_bottom_nav"),
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                navItems.forEach { item ->
                    val isSelected = currentScreen == item.route
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = { viewModel.setScreen(item.route) },
                        icon = {
                            Icon(
                                imageVector = item.icon,
                                contentDescription = item.label,
                                tint = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        },
                        label = {
                            Text(
                                text = item.label,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        modifier = Modifier.testTag("nav_item_${item.route}")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                "home" -> HomeScreen(viewModel = viewModel)
                "wallet" -> WalletScreen(viewModel = viewModel)
                "history" -> HistoryScreen(viewModel = viewModel)
                "plan" -> PlanScreen(viewModel = viewModel)
                "insights" -> InsightsScreen(viewModel = viewModel)
                "settings" -> SettingsScreen(
                    viewModel = viewModel,
                    onOpenImportCsv = { showImportCsvDialog = true }
                )
            }
        }
    }

    // Review Parsed Items BottomSheet
    if (pendingReview != null) {
        ReviewParsedSheet(
            items = pendingReview!!,
            isBangla = isBangla,
            onSave = { viewModel.saveTransactions(pendingReview!!) },
            onDismiss = { viewModel.dismissReview() }
        )
    }

    // Bazar Mode BottomSheet
    if (isBazarModeOpen) {
        BazarModeDialog(
            viewModel = viewModel,
            onDismiss = { viewModel.closeBazarMode() }
        )
    }

    // Paste SMS BottomSheet
    if (isPasteSmsOpen) {
        PasteSmsDialog(
            viewModel = viewModel,
            onDismiss = { viewModel.closePasteSms() }
        )
    }

    // Edit Transaction BottomSheet
    if (editingTx != null) {
        EditTransactionSheet(
            item = editingTx!!,
            isBangla = isBangla,
            wallets = wallets,
            onSave = { updated -> viewModel.updateTransaction(updated) },
            onDismiss = { viewModel.closeEditTransaction() }
        )
    }

    // Wallet Action BottomSheet
    if (walletAction != null) {
        WalletActionDialog(
            action = walletAction!!,
            wallets = wallets,
            isBangla = isBangla,
            viewModel = viewModel,
            onDismiss = { viewModel.closeWalletAction() }
        )
    }

    // Import CSV Dialog
    if (showImportCsvDialog) {
        AlertDialog(
            onDismissRequest = { showImportCsvDialog = false },
            title = { Text(BanglaUtils.tr("Import CSV", isBangla), fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text(
                        "Paste CSV text with header row (e.g. date, title, amount, category).",
                        fontSize = 12.5.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        value = csvInputText,
                        onValueChange = { csvInputText = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp)
                            .padding(top = 8.dp),
                        shape = RoundedCornerShape(12.dp)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val count = viewModel.importCsv(csvInputText)
                        if (count > 0) {
                            showImportCsvDialog = false
                            csvInputText = ""
                        }
                    }
                ) {
                    Text(BanglaUtils.tr("Import", isBangla))
                }
            },
            dismissButton = {
                TextButton(onClick = { showImportCsvDialog = false }) {
                    Text(BanglaUtils.tr("Cancel", isBangla))
                }
            }
        )
    }
}
