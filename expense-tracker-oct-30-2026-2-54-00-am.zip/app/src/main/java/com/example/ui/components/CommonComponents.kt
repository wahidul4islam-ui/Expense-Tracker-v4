package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.TransactionEntity
import com.example.data.parser.BanglaUtils
import com.example.data.parser.CategoryRegistry
import com.example.ui.theme.BankEnd
import com.example.ui.theme.BankStart
import com.example.ui.theme.BkashEnd
import com.example.ui.theme.BkashStart
import com.example.ui.theme.CashEnd
import com.example.ui.theme.CashStart
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.IncomeGreen
import com.example.ui.theme.NagadEnd
import com.example.ui.theme.NagadStart
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun WalletCard(
    walletName: String,
    balance: Double,
    ownerName: String = "",
    isBangla: Boolean = false,
    modifier: Modifier = Modifier
) {
    var isRevealed by remember { mutableStateOf(false) }

    val (startColor, endColor, titleLabel) = when (walletName.lowercase()) {
        "bkash" -> Triple(BkashStart, BkashEnd, "BKASH WALLET")
        "nagad" -> Triple(NagadStart, NagadEnd, "NAGAD WALLET")
        "bank" -> Triple(BankStart, BankEnd, "BANK ACCOUNT")
        "cash" -> Triple(CashStart, CashEnd, "CASH IN HAND")
        else -> Triple(Color(0xFF7C4DD8), Color(0xFF5F37B0), "${walletName.uppercase()} WALLET")
    }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .height(140.dp)
            .testTag("wallet_card_${walletName.lowercase()}"),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Brush.linearGradient(listOf(startColor, endColor)))
                .padding(16.dp)
        ) {
            // Background decorative circle
            Canvas(modifier = Modifier.fillMaxSize()) {
                drawCircle(
                    color = Color.White.copy(alpha = 0.08f),
                    radius = size.width * 0.45f,
                    center = Offset(size.width * 0.95f, size.height * 1.1f)
                )
            }

            Column(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color.White.copy(alpha = 0.25f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = walletName.take(1).uppercase(),
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }
                    Text(
                        text = titleLabel,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        letterSpacing = 0.8.sp
                    )
                }

                // Balance Pill Toggle (Interactive)
                Box(
                    modifier = Modifier
                        .align(Alignment.End)
                        .clip(CircleShape)
                        .background(Color.White)
                        .clickable { isRevealed = !isRevealed }
                        .padding(horizontal = 14.dp, vertical = 7.dp)
                        .testTag("wallet_pill_${walletName.lowercase()}")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(24.dp)
                                .clip(CircleShape)
                                .background(startColor),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "৳",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                        Text(
                            text = if (isRevealed) {
                                BanglaUtils.formatTaka(balance, isBangla)
                            } else {
                                BanglaUtils.tr("Tap For Balance", isBangla)
                            },
                            color = startColor,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                }

                // Footer Owner Label
                Text(
                    text = if (ownerName.isNotBlank()) "$walletName · ${ownerName.uppercase()}" else walletName,
                    color = Color.White.copy(alpha = 0.9f),
                    fontWeight = FontWeight.Medium,
                    fontSize = 12.sp
                )
            }
        }
    }
}

@Composable
fun TransactionRow(
    item: TransactionEntity,
    isBangla: Boolean = false,
    showDate: Boolean = true,
    onEdit: () -> Unit = {},
    onDelete: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val meta = CategoryRegistry.getCategory(item.category)
    val catColor = CategoryRegistry.getColor(item.category)
    val timeStr = remember(item.timestamp) {
        SimpleDateFormat("h:mm a", Locale.ROOT).format(Date(item.timestamp))
    }
    val dateStr = remember(item.timestamp) {
        SimpleDateFormat("d MMM", Locale.ROOT).format(Date(item.timestamp))
    }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .clickable { onEdit() }
            .padding(vertical = 10.dp, horizontal = 4.dp)
            .testTag("tx_row_${item.id}"),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Category Icon Circle
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(catColor.copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center
        ) {
            Text(text = meta.icon, fontSize = 20.sp)
        }

        // Details
        Column(
            modifier = Modifier.weight(1f)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = item.title,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 15.sp,
                    color = MaterialTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (!item.imageUri.isNullOrBlank()) {
                    Spacer(Modifier.width(4.dp))
                    Icon(
                        imageVector = Icons.Default.AttachFile,
                        contentDescription = "Receipt attached",
                        modifier = Modifier.size(14.dp),
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }
            val subText = buildString {
                append(BanglaUtils.tr(item.category, isBangla))
                append(" · ")
                if (showDate) {
                    append(dateStr)
                    append(", ")
                }
                append(timeStr)
                if (item.wallet != "Cash") {
                    append(" · ")
                    append(item.wallet)
                }
                if (item.note.isNotBlank()) {
                    append(" · ")
                    append(item.note)
                }
            }
            Text(
                text = subText,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }

        // Amount
        val isIncome = item.type == "income"
        val amtColor = if (isIncome) IncomeGreen else ExpenseRed
        val amtSign = if (isIncome) "+" else "−"

        Text(
            text = amtSign + BanglaUtils.formatTaka(item.amount, isBangla),
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            color = amtColor
        )

        IconButton(
            onClick = onDelete,
            modifier = Modifier
                .size(32.dp)
                .testTag("delete_tx_${item.id}")
        ) {
            Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "Delete",
                tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
                modifier = Modifier.size(16.dp)
            )
        }
    }
}

@Composable
fun MilestoneProgressBar(
    current: Double,
    target: Double,
    isBangla: Boolean = false,
    barColor: Color = IncomeGreen,
    modifier: Modifier = Modifier
) {
    val progress = if (target > 0) (current / target).toFloat().coerceIn(0f, 1f) else 0f
    val animatedProgress by animateFloatAsState(targetValue = progress, label = "progress")

    Column(modifier = modifier.fillMaxWidth()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
        ) {
            // Fill
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(animatedProgress)
                    .background(barColor)
            )

            // 25%, 50%, 75% tick marks
            Row(
                modifier = Modifier.fillMaxSize(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                repeat(3) {
                    Box(
                        modifier = Modifier
                            .fillMaxHeight()
                            .width(1.5.dp)
                            .background(Color.White.copy(alpha = 0.8f))
                    )
                }
            }
        }
    }
}

@Composable
fun CategoryDonutChart(
    categoryTotals: List<Pair<String, Double>>,
    totalAmount: Double,
    isBangla: Boolean = false,
    modifier: Modifier = Modifier
) {
    if (totalAmount <= 0.0 || categoryTotals.isEmpty()) return

    Box(
        modifier = modifier
            .size(190.dp)
            .padding(8.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val strokeWidth = 24.dp.toPx()
            val diameter = size.minDimension - strokeWidth
            val arcSize = Size(diameter, diameter)
            val topLeft = Offset((size.width - diameter) / 2, (size.height - diameter) / 2)

            var startAngle = -90f
            for ((cat, amount) in categoryTotals) {
                val sweepAngle = ((amount / totalAmount) * 360f).toFloat()
                val color = CategoryRegistry.getColor(cat)
                drawArc(
                    color = color,
                    startAngle = startAngle,
                    sweepAngle = sweepAngle,
                    useCenter = false,
                    topLeft = topLeft,
                    size = arcSize,
                    style = Stroke(width = strokeWidth)
                )
                startAngle += sweepAngle
            }
        }

        // Center Text
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = BanglaUtils.formatTaka(totalAmount, isBangla),
                fontWeight = FontWeight.Bold,
                fontSize = 17.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = BanglaUtils.tr("Total", isBangla),
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
