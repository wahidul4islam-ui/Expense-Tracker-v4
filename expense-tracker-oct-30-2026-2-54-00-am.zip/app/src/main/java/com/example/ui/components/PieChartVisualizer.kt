package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.parser.BanglaUtils
import com.example.data.parser.CategoryRegistry
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

data class PieChartSlice(
    val category: String,
    val amount: Double,
    val percentage: Float,
    val startAngle: Float,
    val sweepAngle: Float,
    val color: Color
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PieChartVisualizer(
    categoryTotals: List<Pair<String, Double>>,
    totalAmount: Double,
    isBangla: Boolean = false,
    modifier: Modifier = Modifier
) {
    if (totalAmount <= 0.0 || categoryTotals.isEmpty()) {
        Card(
            modifier = modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No expenses recorded to visualize yet.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 14.sp
                )
            }
        }
        return
    }

    var isDonutMode by remember { mutableStateOf(false) }
    var selectedCategory by remember { mutableStateOf<String?>(null) }

    // Animation progress (0f to 1f)
    val animationProgress = remember { Animatable(0f) }
    LaunchedEffect(categoryTotals) {
        animationProgress.snapTo(0f)
        animationProgress.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 800, easing = FastOutSlowInEasing)
        )
    }

    // Build slices list
    val slices = remember(categoryTotals, totalAmount) {
        var currentAngle = -90f
        categoryTotals.map { (cat, amt) ->
            val sweep = ((amt / totalAmount) * 360f).toFloat()
            val slice = PieChartSlice(
                category = cat,
                amount = amt,
                percentage = ((amt / totalAmount) * 100f).toFloat(),
                startAngle = currentAngle,
                sweepAngle = sweep,
                color = CategoryRegistry.getColor(cat)
            )
            currentAngle += sweep
            slice
        }
    }

    val selectedSlice = slices.find { it.category == selectedCategory }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("pie_chart_visualizer"),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header with Chart Mode Toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Expense Breakdown",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "By category (Food, Transport, Rent, etc.)",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    FilterChip(
                        selected = !isDonutMode,
                        onClick = { isDonutMode = false },
                        label = { Text("Pie", fontSize = 11.5.sp) }
                    )
                    FilterChip(
                        selected = isDonutMode,
                        onClick = { isDonutMode = true },
                        label = { Text("Donut", fontSize = 11.5.sp) }
                    )
                }
            }

            Spacer(Modifier.height(14.dp))

            // Chart Canvas with Touch Detection
            Box(
                modifier = Modifier
                    .size(240.dp)
                    .padding(8.dp),
                contentAlignment = Alignment.Center
            ) {
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .pointerInput(slices) {
                            detectTapGestures { tapOffset ->
                                val center = Offset(size.width / 2f, size.height / 2f)
                                val dx = tapOffset.x - center.x
                                val dy = tapOffset.y - center.y
                                val distance = sqrt((dx * dx + dy * dy).toDouble())
                                val radius = minOf(size.width, size.height) / 2f

                                // Check if inside the circle
                                if (distance <= radius && (!isDonutMode || distance >= radius * 0.45f)) {
                                    var touchAngle = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat()
                                    // Normalize to [-90, 270)
                                    if (touchAngle < -90f) touchAngle += 360f

                                    val tapped = slices.find { slice ->
                                        val endAngle = slice.startAngle + slice.sweepAngle
                                        touchAngle >= slice.startAngle && touchAngle < endAngle
                                    }
                                    selectedCategory = if (selectedCategory == tapped?.category) null else tapped?.category
                                } else {
                                    selectedCategory = null
                                }
                            }
                        }
                ) {
                    val radius = size.minDimension / 2f
                    val center = Offset(size.width / 2f, size.height / 2f)
                    val strokeWidth = if (isDonutMode) 32.dp.toPx() else 0f

                    for (slice in slices) {
                        val animatedSweep = slice.sweepAngle * animationProgress.value
                        val isSelected = slice.category == selectedCategory

                        // Displace selected slice outward slightly for visual emphasis
                        val angleMidRad = Math.toRadians((slice.startAngle + slice.sweepAngle / 2f).toDouble())
                        val displacement = if (isSelected) 10.dp.toPx() else 0f
                        val sliceCenter = Offset(
                            center.x + (displacement * cos(angleMidRad)).toFloat(),
                            center.y + (displacement * sin(angleMidRad)).toFloat()
                        )

                        val drawRadius = radius - if (isDonutMode) strokeWidth / 2f else 0f
                        val arcTopLeft = Offset(sliceCenter.x - drawRadius, sliceCenter.y - drawRadius)
                        val arcSize = Size(drawRadius * 2f, drawRadius * 2f)

                        if (isDonutMode) {
                            drawArc(
                                color = slice.color,
                                startAngle = slice.startAngle,
                                sweepAngle = animatedSweep,
                                useCenter = false,
                                topLeft = arcTopLeft,
                                size = arcSize,
                                style = Stroke(width = strokeWidth)
                            )
                        } else {
                            drawArc(
                                color = slice.color,
                                startAngle = slice.startAngle,
                                sweepAngle = animatedSweep,
                                useCenter = true,
                                topLeft = arcTopLeft,
                                size = arcSize
                            )
                        }
                    }
                }

                // Center Text (in Donut mode or general center callout)
                if (isDonutMode) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        if (selectedSlice != null) {
                            val meta = CategoryRegistry.getCategory(selectedSlice.category)
                            Text(text = meta.icon, fontSize = 22.sp)
                            Text(
                                text = BanglaUtils.formatTaka(selectedSlice.amount, isBangla),
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "${selectedSlice.percentage.toInt()}%",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        } else {
                            Text(
                                text = BanglaUtils.formatTaka(totalAmount, isBangla),
                                fontWeight = FontWeight.Bold,
                                fontSize = 18.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = BanglaUtils.tr("Total", isBangla),
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // Selected Slice Highlight Card
            AnimatedVisibility(visible = selectedSlice != null) {
                if (selectedSlice != null) {
                    val meta = CategoryRegistry.getCategory(selectedSlice.category)
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = selectedSlice.color.copy(alpha = 0.15f),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(meta.icon, fontSize = 20.sp)
                                Column {
                                    Text(
                                        text = selectedSlice.category,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                    Text(
                                        text = "${selectedSlice.percentage.toInt()}% of total expenses",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Text(
                                text = BanglaUtils.formatTaka(selectedSlice.amount, isBangla),
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 16.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.height(10.dp))

            // Interactive Flow Legend of Categories
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                for (slice in slices) {
                    val isSelected = slice.category == selectedCategory
                    val meta = CategoryRegistry.getCategory(slice.category)

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (isSelected) slice.color.copy(alpha = 0.25f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .clickable {
                                selectedCategory = if (selectedCategory == slice.category) null else slice.category
                            }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(slice.color)
                            )
                            Text(
                                text = "${meta.icon} ${slice.category}",
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                            )
                            Text(
                                text = "${slice.percentage.toInt()}%",
                                fontSize = 11.5.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}
