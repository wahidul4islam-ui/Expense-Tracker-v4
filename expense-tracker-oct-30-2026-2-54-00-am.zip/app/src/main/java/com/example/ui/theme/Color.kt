package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val GreenPrimary = Color(0xFF0E8A63)
val GreenSecondary = Color(0xFF25B685)
val GreenTertiary = Color(0xFF0B7656)

val BluePrimary = Color(0xFF2F6FE0)
val BlueSecondary = Color(0xFF5B9BFF)
val BlueTertiary = Color(0xFF2457B8)

val PurplePrimary = Color(0xFF7C4DD8)
val PurpleSecondary = Color(0xFFA07CF0)
val PurpleTertiary = Color(0xFF5F37B0)

val OrangePrimary = Color(0xFFE0731F)
val OrangeSecondary = Color(0xFFF5A35C)
val OrangeTertiary = Color(0xFFB85A12)

val PinkPrimary = Color(0xFFD6477F)
val PinkSecondary = Color(0xFFF08AB0)
val PinkTertiary = Color(0xFFB0305F)

val LightBackground = Color(0xFFF3F7F5)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE8F0EC)
val LightOnSurface = Color(0xFF10201A)
val LightOnSurfaceVariant = Color(0xFF5B6E65)

val DarkBackground = Color(0xFF0B1410)
val DarkSurface = Color(0xFF15201B)
val DarkSurfaceVariant = Color(0xFF1D2A24)
val DarkOnSurface = Color(0xFFE6EFE9)
val DarkOnSurfaceVariant = Color(0xFF8FA59A)

val IncomeGreen = Color(0xFF14925F)
val ExpenseRed = Color(0xFFD6453D)

// Brand colors for wallets
val BkashStart = Color(0xFFE2136E)
val BkashEnd = Color(0xFFA50D52)

val NagadStart = Color(0xFFF7941D)
val NagadEnd = Color(0xFFEC1C24)

val BankStart = Color(0xFF1D8AD6)
val BankEnd = Color(0xFF0A4AA3)

val CashStart = Color(0xFF0B7656)
val CashEnd = Color(0xFF25B685)
