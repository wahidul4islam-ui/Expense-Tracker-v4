package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.DebtEntity
import com.example.data.local.SavingsGoalEntity
import com.example.data.local.TourEntity
import com.example.data.parser.BanglaUtils
import com.example.data.parser.CategoryRegistry
import com.example.ui.components.MilestoneProgressBar
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.IncomeGreen
import com.example.ui.viewmodel.ExpenseViewModel
import org.json.JSONArray
import java.text.SimpleDateFormat
import java.util.Calendar
import androidx.compose.ui.graphics.Color
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlanScreen(
    viewModel: ExpenseViewModel,
    modifier: Modifier = Modifier
) {
    val planTab by viewModel.planTab.collectAsState()
    val isBangla = viewModel.prefs.language.collectAsState().value == "bn"

    val debts by viewModel.debts.collectAsState()
    val savingsGoals by viewModel.savingsGoals.collectAsState()
    val fixedBills by viewModel.fixedBills.collectAsState()
    val budgets by viewModel.budgets.collectAsState()
    val tours by viewModel.tours.collectAsState()
    val activeTourId by viewModel.activeTourId.collectAsState()
    val transactions by viewModel.transactions.collectAsState()

    val currentMonthKey = remember {
        val cal = Calendar.getInstance()
        "${cal.get(Calendar.YEAR)}-${cal.get(Calendar.MONTH)}"
    }
    val monthExpensesByCategory = remember(transactions) {
        transactions.filter {
            val c = Calendar.getInstance().apply { timeInMillis = it.timestamp }
            "${c.get(Calendar.YEAR)}-${c.get(Calendar.MONTH)}" == currentMonthKey && it.type == "expense"
        }.groupBy { it.category }.mapValues { it.value.sumOf { tx -> tx.amount } }
    }

    val tabs = listOf(
        "debt" to BanglaUtils.tr("Debt", isBangla),
        "goal" to BanglaUtils.tr("Savings", isBangla),
        "fx" to BanglaUtils.tr("Monthly", isBangla),
        "bud" to BanglaUtils.tr("Budget", isBangla),
        "trip" to BanglaUtils.tr("Tour", isBangla)
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
    ) {
        Spacer(Modifier.height(8.dp))
        Text(
            text = BanglaUtils.tr("Plan", isBangla),
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(Modifier.height(10.dp))

        // Tabs Row
        PrimaryTabRow(
            selectedTabIndex = tabs.indexOfFirst { it.first == planTab }.coerceAtLeast(0),
            containerColor = MaterialTheme.colorScheme.surface,
            modifier = Modifier.padding(bottom = 12.dp)
        ) {
            tabs.forEach { (key, label) ->
                Tab(
                    selected = planTab == key,
                    onClick = { viewModel.setPlanTab(key) },
                    text = { Text(label, fontWeight = FontWeight.SemiBold, fontSize = 13.sp) },
                    modifier = Modifier.testTag("plan_tab_$key")
                )
            }
        }

        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            when (planTab) {
                "debt" -> {
                    // Debt summary card
                    val iOwe = debts.filter { it.direction == "b" }.sumOf { d ->
                        val paid = parseDebtPayments(d.paymentsJson).sumOf { it.amount }
                        d.total - paid
                    }
                    val owedToMe = debts.filter { it.direction == "l" }.sumOf { d ->
                        val paid = parseDebtPayments(d.paymentsJson).sumOf { it.amount }
                        d.total - paid
                    }

                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(16.dp),
                                horizontalArrangement = Arrangement.SpaceAround
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = BanglaUtils.tr("I owe", isBangla),
                                        fontSize = 13.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = BanglaUtils.formatTaka(iOwe, isBangla),
                                        fontSize = 22.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = ExpenseRed
                                    )
                                }
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text(
                                        text = BanglaUtils.tr("Owed to me", isBangla),
                                        fontSize = 13.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = BanglaUtils.formatTaka(owedToMe, isBangla),
                                        fontSize = 22.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = IncomeGreen
                                    )
                                }
                            }
                        }
                    }

                    // Existing Debts
                    items(debts, key = { it.id }) { debt ->
                        DebtCardItem(debt = debt, isBangla = isBangla, viewModel = viewModel)
                    }

                    // New Debt Form
                    item {
                        NewDebtForm(isBangla = isBangla, onAdd = { who, amt, dir, date ->
                            viewModel.addDebt(who, amt, dir, date)
                        })
                    }
                }

                "goal" -> {
                    val totalSaved = savingsGoals.sumOf { g ->
                        parseDebtPayments(g.paymentsJson).sumOf { it.amount }
                    }

                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = BanglaUtils.tr("Total saved", isBangla),
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = BanglaUtils.formatTaka(totalSaved, isBangla),
                                    fontSize = 26.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = IncomeGreen
                                )
                            }
                        }
                    }

                    items(savingsGoals, key = { it.id }) { goal ->
                        SavingsGoalCardItem(goal = goal, isBangla = isBangla, viewModel = viewModel)
                    }

                    item {
                        NewGoalForm(isBangla = isBangla, onAdd = { title, target ->
                            viewModel.addSavingsGoal(title, target)
                        })
                    }
                }

                "fx" -> {
                    item {
                        Text(
                            text = "Bills here show on Home each month until you tap Pay.",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    items(fixedBills, key = { it.id }) { bill ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val meta = CategoryRegistry.getCategory(bill.category)
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(42.dp)
                                            .background(
                                                CategoryRegistry.getColor(bill.category).copy(alpha = 0.2f),
                                                RoundedCornerShape(12.dp)
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(meta.icon, fontSize = 20.sp)
                                    }
                                    Column {
                                        Text(bill.title, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                                        Text(
                                            text = "${BanglaUtils.formatTaka(bill.amount, isBangla)} · day ${bill.day} · ${bill.type}",
                                            fontSize = 12.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                IconButton(onClick = { viewModel.deleteFixedBill(bill.id) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = ExpenseRed)
                                }
                            }
                        }
                    }

                    item {
                        NewFixedBillForm(isBangla = isBangla, onAdd = { title, amt, day, cat, type ->
                            viewModel.addFixedBill(title, amt, day, cat, type)
                        })
                    }
                }

                "bud" -> {
                    items(budgets, key = { it.category }) { budget ->
                        val spent = monthExpensesByCategory[budget.category] ?: 0.0
                        val pct = if (budget.limitAmount > 0) ((spent / budget.limitAmount) * 100).toInt() else 0
                        val meta = CategoryRegistry.getCategory(budget.category)
                        val barColor = when {
                            pct >= 100 -> ExpenseRed
                            pct >= 80 -> Color(0xFFE0B43A)
                            else -> IncomeGreen
                        }

                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Text(meta.icon, fontSize = 20.sp)
                                        Text(budget.category, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                    }
                                    IconButton(onClick = { viewModel.deleteBudget(budget.category) }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = ExpenseRed)
                                    }
                                }
                                Spacer(Modifier.height(6.dp))
                                MilestoneProgressBar(current = spent, target = budget.limitAmount, barColor = barColor)
                                Spacer(Modifier.height(6.dp))
                                val remaining = budget.limitAmount - spent
                                val statusText = if (remaining < 0) {
                                    "over by " + BanglaUtils.formatTaka(-remaining, isBangla)
                                } else {
                                    BanglaUtils.formatTaka(remaining, isBangla) + " left"
                                }
                                Text(
                                    text = "${BanglaUtils.formatTaka(spent, isBangla)} of ${BanglaUtils.formatTaka(budget.limitAmount, isBangla)} this month · $statusText",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    item {
                        NewBudgetForm(isBangla = isBangla, onAdd = { cat, limit ->
                            viewModel.setBudget(cat, limit)
                        })
                    }
                }

                "trip" -> {
                    val activeTour = tours.find { it.id == activeTourId }
                    if (activeTour == null) {
                        // Tours list
                        items(tours, key = { it.id }) { tour ->
                            val expenses = viewModel.parseTourExpenses(tour.expensesJson)
                            val totalSpent = expenses.sumOf { it.amount }
                            val people = viewModel.parseTourPeople(tour.peopleJson)

                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable { viewModel.openTourDetail(tour.id) },
                                shape = RoundedCornerShape(16.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("✈️ ${tour.name}", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                        Text(
                                            BanglaUtils.formatTaka(totalSpent, isBangla),
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 16.sp
                                        )
                                    }
                                    Spacer(Modifier.height(4.dp))
                                    val budgetStr = if (tour.budget > 0) " · budget " + BanglaUtils.formatTaka(tour.budget, isBangla) else ""
                                    Text(
                                        text = "${people.size} people$budgetStr",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    if (tour.budget > 0) {
                                        Spacer(Modifier.height(6.dp))
                                        MilestoneProgressBar(current = totalSpent, target = tour.budget)
                                    }
                                }
                            }
                        }

                        item {
                            NewTourForm(isBangla = isBangla, onAdd = { name, budget, friends ->
                                viewModel.createTour(name, budget, friends)
                            })
                        }
                    } else {
                        // Active Tour Detail View
                        item {
                            TourDetailView(tour = activeTour, isBangla = isBangla, viewModel = viewModel)
                        }
                    }
                }
            }

            item { Spacer(Modifier.height(80.dp)) }
        }
    }
}

@Composable
fun DebtCardItem(
    debt: DebtEntity,
    isBangla: Boolean,
    viewModel: ExpenseViewModel
) {
    val payments = parseDebtPayments(debt.paymentsJson)
    val paid = payments.sumOf { it.amount }
    val remaining = debt.total - paid
    var payAmountInput by remember { mutableStateOf("") }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(debt.who, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                val label = if (debt.direction == "b") BanglaUtils.tr("I owe", isBangla) else BanglaUtils.tr("Owes me", isBangla)
                val color = if (debt.direction == "b") ExpenseRed else IncomeGreen
                Text(
                    text = "$label ${BanglaUtils.formatTaka(debt.total, isBangla)}",
                    fontWeight = FontWeight.Bold,
                    color = color
                )
            }
            Text("Since ${debt.date}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(8.dp))
            MilestoneProgressBar(current = paid, target = debt.total)
            Spacer(Modifier.height(6.dp))
            val action = if (debt.direction == "b") "paid" else "received"
            Text(
                text = "${BanglaUtils.formatTaka(paid, isBangla)} $action · ${BanglaUtils.formatTaka(remaining, isBangla)} left",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            // Payments history
            for (p in payments) {
                Text("✓ ${p.date} · ${BanglaUtils.formatTaka(p.amount, isBangla)}", fontSize = 11.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            if (remaining > 0) {
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = payAmountInput,
                        onValueChange = { payAmountInput = it },
                        placeholder = { Text(if (debt.direction == "b") "Paid amount" else "Received amount") },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true
                    )
                    Button(
                        onClick = {
                            val amt = payAmountInput.toDoubleOrNull() ?: 0.0
                            if (amt > 0) {
                                val today = SimpleDateFormat("yyyy-MM-dd", Locale.ROOT).format(Date())
                                viewModel.addDebtPayment(debt, amt, today)
                                payAmountInput = ""
                            }
                        },
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(BanglaUtils.tr("Add payment", isBangla), fontSize = 12.sp)
                    }
                }
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = { viewModel.deleteDebt(debt.id) }) {
                    Text(BanglaUtils.tr("Delete", isBangla), color = ExpenseRed)
                }
            }
        }
    }
}

@Composable
fun SavingsGoalCardItem(
    goal: SavingsGoalEntity,
    isBangla: Boolean,
    viewModel: ExpenseViewModel
) {
    val payments = parseDebtPayments(goal.paymentsJson)
    val saved = payments.sumOf { it.amount }
    val remaining = goal.target - saved
    var saveAmountInput by remember { mutableStateOf("") }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(goal.title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(
                    BanglaUtils.formatTaka(goal.target, isBangla),
                    fontWeight = FontWeight.Bold,
                    color = IncomeGreen
                )
            }
            Spacer(Modifier.height(8.dp))
            MilestoneProgressBar(current = saved, target = goal.target)
            Spacer(Modifier.height(6.dp))
            Text(
                text = "${BanglaUtils.formatTaka(saved, isBangla)} saved · ${BanglaUtils.formatTaka(remaining, isBangla)} to go",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = saveAmountInput,
                    onValueChange = { saveAmountInput = it },
                    placeholder = { Text("Add savings amount") },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp),
                    singleLine = true
                )
                Button(
                    onClick = {
                        val amt = saveAmountInput.toDoubleOrNull() ?: 0.0
                        if (amt > 0) {
                            viewModel.contributeSavingsGoal(goal, amt)
                            saveAmountInput = ""
                        }
                    },
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text(BanglaUtils.tr("Save money", isBangla), fontSize = 12.sp)
                }
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = { viewModel.deleteSavingsGoal(goal.id) }) {
                    Text(BanglaUtils.tr("Delete", isBangla), color = ExpenseRed)
                }
            }
        }
    }
}

@Composable
fun TourDetailView(
    tour: TourEntity,
    isBangla: Boolean,
    viewModel: ExpenseViewModel
) {
    val expenses = viewModel.parseTourExpenses(tour.expensesJson)
    val people = viewModel.parseTourPeople(tour.peopleJson)
    val totalSpent = expenses.sumOf { it.amount }
    val perPerson = if (people.isNotEmpty()) totalSpent / people.size else 0.0
    val settlements = viewModel.calculateTourSettlement(people, expenses)

    var expenseQuery by remember { mutableStateOf("") }
    var selectedPayer by remember { mutableStateOf(people.firstOrNull() ?: "Me") }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            TextButton(onClick = { viewModel.closeTourDetail() }) {
                Text("‹ " + BanglaUtils.tr("All tours", isBangla))
            }
            IconButton(onClick = { viewModel.deleteTour(tour.id) }) {
                Icon(Icons.Default.Delete, contentDescription = "Delete Tour", tint = ExpenseRed)
            }
        }

        Text("✈️ ${tour.name}", fontSize = 22.sp, fontWeight = FontWeight.Bold)

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        BanglaUtils.formatTaka(totalSpent, isBangla),
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        "${BanglaUtils.formatTaka(perPerson, isBangla)} each",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                if (tour.budget > 0) {
                    Spacer(Modifier.height(6.dp))
                    MilestoneProgressBar(current = totalSpent, target = tour.budget)
                    Text(
                        text = if (totalSpent > tour.budget) "Over budget by ${BanglaUtils.formatTaka(totalSpent - tour.budget, isBangla)}"
                        else "${BanglaUtils.formatTaka(tour.budget - totalSpent, isBangla)} left of ${BanglaUtils.formatTaka(tour.budget, isBangla)}",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Add Tour Expense Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(BanglaUtils.tr("Add expenses", isBangla), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                OutlinedTextField(
                    value = expenseQuery,
                    onValueChange = { expenseQuery = it },
                    placeholder = { Text("hotel 3000, bus 800…") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                Button(
                    onClick = {
                        val parsed = com.example.data.parser.SmartParser.parseInput(expenseQuery)
                        if (parsed.isNotEmpty()) {
                            for (p in parsed) {
                                viewModel.addTourExpense(tour, p.title, p.amount, p.category, selectedPayer)
                            }
                            expenseQuery = ""
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(BanglaUtils.tr("Add", isBangla))
                }
            }
        }

        // Expenses list
        for (e in expenses.reversed()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(e.title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        Text("${e.category} · ${e.date} · paid by ${e.paidBy}", fontSize = 11.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(BanglaUtils.formatTaka(e.amount, isBangla), fontWeight = FontWeight.Bold, color = ExpenseRed)
                        IconButton(onClick = { viewModel.deleteTourExpense(tour, e.id) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = ExpenseRed, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        }

        // Settle up Card
        if (settlements.isNotEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(BanglaUtils.tr("Settle up", isBangla), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(Modifier.height(6.dp))
                    for (st in settlements) {
                        Text("• $st", fontSize = 13.5.sp, color = MaterialTheme.colorScheme.onSurface)
                    }
                }
            }
        }

        if (totalSpent > 0) {
            Button(
                onClick = { viewModel.addMyTourShareToBalance(tour) },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    "Add my share (${BanglaUtils.formatTaka(perPerson, isBangla)}) to balance",
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}

@Composable
fun NewDebtForm(isBangla: Boolean, onAdd: (String, Double, String, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var dir by remember { mutableStateOf("b") } // "b" = I borrowed, "l" = I lent

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(BanglaUtils.tr("New debt", isBangla), fontWeight = FontWeight.Bold, fontSize = 14.sp)
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                placeholder = { Text(BanglaUtils.tr("Name", isBangla)) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )
            OutlinedTextField(
                value = amount,
                onValueChange = { amount = it },
                placeholder = { Text(BanglaUtils.tr("Amount", isBangla)) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { dir = "b" },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (dir == "b") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
                    ),
                    modifier = Modifier.weight(1f)
                ) {
                    Text(BanglaUtils.tr("I owe", isBangla), color = if (dir == "b") Color.White else MaterialTheme.colorScheme.onSurface)
                }
                Button(
                    onClick = { dir = "l" },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (dir == "l") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
                    ),
                    modifier = Modifier.weight(1f)
                ) {
                    Text(BanglaUtils.tr("Owes me", isBangla), color = if (dir == "l") Color.White else MaterialTheme.colorScheme.onSurface)
                }
            }
            Button(
                onClick = {
                    val amt = amount.toDoubleOrNull() ?: 0.0
                    if (name.isNotBlank() && amt > 0) {
                        val today = SimpleDateFormat("yyyy-MM-dd", Locale.ROOT).format(Date())
                        onAdd(name, amt, dir, today)
                        name = ""
                        amount = ""
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(BanglaUtils.tr("Add", isBangla))
            }
        }
    }
}

@Composable
fun NewGoalForm(isBangla: Boolean, onAdd: (String, Double) -> Unit) {
    var title by remember { mutableStateOf("") }
    var target by remember { mutableStateOf("") }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(BanglaUtils.tr("New goal", isBangla), fontWeight = FontWeight.Bold, fontSize = 14.sp)
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                placeholder = { Text("Goal (e.g. Laptop)") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )
            OutlinedTextField(
                value = target,
                onValueChange = { target = it },
                placeholder = { Text("Target amount") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )
            Button(
                onClick = {
                    val amt = target.toDoubleOrNull() ?: 0.0
                    if (title.isNotBlank() && amt > 0) {
                        onAdd(title, amt)
                        title = ""
                        target = ""
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(BanglaUtils.tr("Add goal", isBangla))
            }
        }
    }
}

@Composable
fun NewFixedBillForm(
    isBangla: Boolean,
    onAdd: (String, Double, Int, String, String) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var amount by remember { mutableStateOf("") }
    var day by remember { mutableStateOf("1") }
    var type by remember { mutableStateOf("expense") }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(BanglaUtils.tr("Monthly fixed", isBangla), fontWeight = FontWeight.Bold, fontSize = 14.sp)
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                placeholder = { Text("Name (basha vara, wifi…)") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )
            OutlinedTextField(
                value = amount,
                onValueChange = { amount = it },
                placeholder = { Text(BanglaUtils.tr("Amount", isBangla)) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )
            OutlinedTextField(
                value = day,
                onValueChange = { day = it },
                placeholder = { Text("Day of month (1-31)") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )
            Button(
                onClick = {
                    val amt = amount.toDoubleOrNull() ?: 0.0
                    val d = day.toIntOrNull() ?: 1
                    if (title.isNotBlank() && amt > 0) {
                        onAdd(title, amt, d, "Utilities", type)
                        title = ""
                        amount = ""
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(BanglaUtils.tr("Add", isBangla))
            }
        }
    }
}

@Composable
fun NewBudgetForm(isBangla: Boolean, onAdd: (String, Double) -> Unit) {
    val categories = CategoryRegistry.categories.keys.filter { it != "Salary" && it != "Income" }
    var selectedCat by remember { mutableStateOf(categories.firstOrNull() ?: "Food") }
    var limit by remember { mutableStateOf("") }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(BanglaUtils.tr("New budget", isBangla), fontWeight = FontWeight.Bold, fontSize = 14.sp)
            OutlinedTextField(
                value = limit,
                onValueChange = { limit = it },
                placeholder = { Text("Monthly limit for $selectedCat") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )
            Button(
                onClick = {
                    val amt = limit.toDoubleOrNull() ?: 0.0
                    if (amt > 0) {
                        onAdd(selectedCat, amt)
                        limit = ""
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(BanglaUtils.tr("Budget", isBangla))
            }
        }
    }
}

@Composable
fun NewTourForm(isBangla: Boolean, onAdd: (String, Double, List<String>) -> Unit) {
    var name by remember { mutableStateOf("") }
    var budget by remember { mutableStateOf("") }
    var friends by remember { mutableStateOf("") }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(BanglaUtils.tr("Create tour", isBangla), fontWeight = FontWeight.Bold, fontSize = 14.sp)
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                placeholder = { Text("Tour name (Cox’s Bazar)") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )
            OutlinedTextField(
                value = budget,
                onValueChange = { budget = it },
                placeholder = { Text("Budget (optional)") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )
            OutlinedTextField(
                value = friends,
                onValueChange = { friends = it },
                placeholder = { Text("Friends, comma separated (e.g. Rahim, Karim)") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )
            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        val b = budget.toDoubleOrNull() ?: 0.0
                        val fList = friends.split(",").map { it.trim() }.filter { it.isNotBlank() }
                        onAdd(name, b, fList)
                        name = ""
                        budget = ""
                        friends = ""
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(BanglaUtils.tr("Create tour", isBangla))
            }
        }
    }
}

private fun parseDebtPayments(jsonStr: String): List<com.example.data.model.DebtPayment> {
    return try {
        val array = JSONArray(jsonStr)
        val list = mutableListOf<com.example.data.model.DebtPayment>()
        for (i in 0 until array.length()) {
            val obj = array.getJSONObject(i)
            list.add(com.example.data.model.DebtPayment(amount = obj.optDouble("amt", 0.0), date = obj.optString("date", "")))
        }
        list
    } catch (e: Exception) {
        emptyList()
    }
}
