package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.parser.BanglaUtils
import com.example.ui.theme.BluePrimary
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.GreenPrimary
import com.example.ui.theme.OrangePrimary
import com.example.ui.theme.PinkPrimary
import com.example.ui.theme.PurplePrimary
import com.example.ui.viewmodel.ExpenseViewModel

@Composable
fun SettingsScreen(
    viewModel: ExpenseViewModel,
    onOpenImportCsv: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val isBangla = viewModel.prefs.language.collectAsState().value == "bn"
    val transactions by viewModel.transactions.collectAsState()

    val userName by viewModel.prefs.userName.collectAsState()
    val appTheme by viewModel.prefs.theme.collectAsState()
    val accent by viewModel.prefs.accent.collectAsState()
    val language by viewModel.prefs.language.collectAsState()
    val reviewBeforeSave by viewModel.prefs.reviewBeforeSave.collectAsState()
    val pin by viewModel.prefs.pin.collectAsState()

    var nameInput by remember(userName) { mutableStateOf(userName) }
    var pinInput by remember { mutableStateOf("") }
    var showDeleteConfirm by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(Modifier.height(8.dp))
            // App Branding Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp),
                modifier = Modifier.padding(bottom = 6.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(56.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(MaterialTheme.colorScheme.primary),
                    contentAlignment = Alignment.Center
                ) {
                    Text("৳", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                }
                Column {
                    Text(
                        text = "Expense Tracker",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "${transactions.size} transactions on this device",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // --- Profile Section ---
        item {
            Text(
                text = BanglaUtils.tr("Profile", isBangla),
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = nameInput,
                        onValueChange = { nameInput = it },
                        placeholder = { Text(BanglaUtils.tr("Your name", isBangla)) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        singleLine = true
                    )
                    Button(
                        onClick = {
                            viewModel.prefs.setUserName(nameInput.trim())
                            viewModel.showToast(if (nameInput.isNotBlank()) "Saved, hi $nameInput" else "Name cleared")
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(BanglaUtils.tr("Save name", isBangla), color = MaterialTheme.colorScheme.onSurface)
                    }
                }
            }
        }

        // --- Appearance Section ---
        item {
            Text(
                text = BanglaUtils.tr("Appearance", isBangla),
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    // Theme Mode
                    SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                        val themes = listOf(
                            "system" to BanglaUtils.tr("System", isBangla),
                            "light" to BanglaUtils.tr("Light", isBangla),
                            "dark" to BanglaUtils.tr("Dark", isBangla)
                        )
                        themes.forEachIndexed { index, (tKey, tLabel) ->
                            SegmentedButton(
                                selected = appTheme == tKey,
                                onClick = { viewModel.prefs.setTheme(tKey) },
                                shape = SegmentedButtonDefaults.itemShape(index, themes.size)
                            ) {
                                Text(tLabel, fontSize = 12.sp)
                            }
                        }
                    }

                    // Language Toggle
                    SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                        val languages = listOf("en" to "English", "bn" to "বাংলা")
                        languages.forEachIndexed { index, (lKey, lLabel) ->
                            SegmentedButton(
                                selected = language == lKey,
                                onClick = { viewModel.prefs.setLanguage(lKey) },
                                shape = SegmentedButtonDefaults.itemShape(index, languages.size)
                            ) {
                                Text(lLabel, fontSize = 12.sp)
                            }
                        }
                    }

                    // Accent Color Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = BanglaUtils.tr("Accent color", isBangla),
                            fontWeight = FontWeight.Medium,
                            fontSize = 14.sp
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            val accents = listOf(
                                "green" to GreenPrimary,
                                "blue" to BluePrimary,
                                "purple" to PurplePrimary,
                                "orange" to OrangePrimary,
                                "pink" to PinkPrimary
                            )
                            for ((aKey, aColor) in accents) {
                                Box(
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(CircleShape)
                                        .background(aColor)
                                        .then(
                                            if (accent == aKey) {
                                                Modifier.border(2.dp, MaterialTheme.colorScheme.onSurface, CircleShape)
                                            } else Modifier
                                        )
                                        .clickable { viewModel.prefs.setAccent(aKey) }
                                )
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = BanglaUtils.tr("Currency", isBangla),
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium
                        )
                        Text(
                            text = "Bangladeshi Taka (৳)",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // --- Smart Entry Section ---
        item {
            Text(
                text = BanglaUtils.tr("Smart entry", isBangla),
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = BanglaUtils.tr("Review before saving", isBangla),
                                fontWeight = FontWeight.Medium,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "Preview what was parsed before it is saved",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = reviewBeforeSave,
                            onCheckedChange = { viewModel.prefs.setReviewBeforeSave(it) },
                            modifier = Modifier.testTag("toggle_review_before_saving")
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = BanglaUtils.tr("Learned items", isBangla),
                                fontWeight = FontWeight.Medium,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "Saved category associations from your edits",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        TextButton(onClick = {
                            viewModel.prefs.clearLearnedCategories()
                            viewModel.showToast("Forgot learned items")
                        }) {
                            Text(BanglaUtils.tr("Forget", isBangla))
                        }
                    }
                }
            }
        }

        // --- Your Data Section ---
        item {
            Text(
                text = BanglaUtils.tr("Your data", isBangla),
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Stored only on this device. No account, no cloud, no tracking.",
                        fontSize = 12.5.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Button(
                        onClick = {
                            val csvData = viewModel.exportCsv()
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            clipboard.setPrimaryClip(ClipData.newPlainText("Expenses CSV", csvData))
                            viewModel.showToast("CSV copied to clipboard")
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(BanglaUtils.tr("Copy CSV", isBangla), color = MaterialTheme.colorScheme.onSurface)
                    }

                    Button(
                        onClick = { onOpenImportCsv() },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(BanglaUtils.tr("Import CSV", isBangla), color = MaterialTheme.colorScheme.onSurface)
                    }

                    // PIN Lock section
                    if (pin.isNotBlank()) {
                        Button(
                            onClick = {
                                viewModel.prefs.setPin("")
                                viewModel.showToast("PIN lock removed")
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Remove PIN lock", color = MaterialTheme.colorScheme.onSurface)
                        }
                    } else {
                        OutlinedTextField(
                            value = pinInput,
                            onValueChange = { if (it.length <= 6) pinInput = it },
                            placeholder = { Text("Set a 4 to 6 digit PIN") },
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            singleLine = true,
                            visualTransformation = PasswordVisualTransformation()
                        )
                        Button(
                            onClick = {
                                if (pinInput.length in 4..6) {
                                    viewModel.prefs.setPin(pinInput)
                                    pinInput = ""
                                    viewModel.showToast("PIN lock is on")
                                } else {
                                    viewModel.showToast("PIN must be 4 to 6 digits")
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Turn on PIN lock", color = MaterialTheme.colorScheme.onSurface)
                        }
                    }

                    // Delete All Data button
                    if (!showDeleteConfirm) {
                        Button(
                            onClick = { showDeleteConfirm = true },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(BanglaUtils.tr("Delete all data", isBangla), color = ExpenseRed)
                        }
                    } else {
                        Button(
                            onClick = {
                                viewModel.clearAllData()
                                showDeleteConfirm = false
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = ExpenseRed),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Tap again to delete everything", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        item { Spacer(Modifier.height(80.dp)) }
    }
}
