package com.example.ui.screens

import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.SuggestionChipDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.parser.BanglaUtils
import com.example.data.parser.CategoryRegistry
import com.example.ui.components.TransactionRow
import com.example.ui.theme.CashEnd
import com.example.ui.theme.CashStart
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.IncomeGreen
import com.example.ui.viewmodel.ExpenseViewModel
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(
    viewModel: ExpenseViewModel,
    modifier: Modifier = Modifier
) {
    val userName by viewModel.prefs.userName.collectAsState()
    val isBangla = viewModel.prefs.language.collectAsState().value == "bn"
    val transactions by viewModel.transactions.collectAsState()
    val fixedBills by viewModel.fixedBills.collectAsState()
    val budgets by viewModel.budgets.collectAsState()
    val isAiParsing by viewModel.isAiParsing.collectAsState()

    var inputQuery by remember { mutableStateOf("") }

    val speechLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spokenText = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spokenText.isNullOrBlank()) {
                inputQuery = spokenText
                viewModel.submitNaturalInput(spokenText)
            }
        }
    }

    val cal = Calendar.getInstance()
    val currentMonthKey = "${cal.get(Calendar.YEAR)}-${cal.get(Calendar.MONTH)}"
    val todayDateStr = SimpleDateFormat("yyyy-MM-dd", Locale.ROOT).format(Date())

    // Calculations
    val totalBalance = viewModel.getTotalBalance()

    val monthTransactions = transactions.filter {
        val c = Calendar.getInstance().apply { timeInMillis = it.timestamp }
        "${c.get(Calendar.YEAR)}-${c.get(Calendar.MONTH)}" == currentMonthKey
    }
    val monthIncome = monthTransactions.filter { it.type == "income" }.sumOf { it.amount }
    val monthExpense = monthTransactions.filter { it.type == "expense" }.sumOf { it.amount }

    val todayTransactions = transactions.filter {
        SimpleDateFormat("yyyy-MM-dd", Locale.ROOT).format(Date(it.timestamp)) == todayDateStr
    }
    val todayNet = todayTransactions.filter { it.type == "income" }.sumOf { it.amount } -
            todayTransactions.filter { it.type == "expense" }.sumOf { it.amount }

    // Budget warnings (>= 80%)
    val budgetAlerts = remember(transactions, budgets) {
        val categoryExpenses = monthTransactions.filter { it.type == "expense" }
            .groupBy { it.category }
            .mapValues { it.value.sumOf { tx -> tx.amount } }

        budgets.mapNotNull { b ->
            val spent = categoryExpenses[b.category] ?: 0.0
            if (spent >= b.limitAmount * 0.8) {
                Triple(b.category, spent, b.limitAmount)
            } else null
        }
    }

    // Unpaid monthly fixed bills
    val unpaidBills = remember(fixedBills) {
        fixedBills.filter { it.paidMonth != currentMonthKey }
    }

    // Streak calculation (days with 0 expenses)
    val streakDays = remember(transactions) {
        val expenseDates = transactions.filter { it.type == "expense" }
            .map { SimpleDateFormat("yyyy-MM-dd", Locale.ROOT).format(Date(it.timestamp)) }
            .toSet()

        var count = 0
        val checkCal = Calendar.getInstance()
        for (i in 0 until 30) {
            val dStr = SimpleDateFormat("yyyy-MM-dd", Locale.ROOT).format(checkCal.time)
            if (!expenseDates.contains(dStr)) {
                count++
            } else {
                if (i > 0) break
            }
            checkCal.add(Calendar.DAY_OF_YEAR, -1)
        }
        count
    }

    val recentTransactions = transactions.take(6)

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // --- Header Section ---
        item {
            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    if (userName.isNotBlank()) {
                        Text(
                            text = "Hi, $userName 👋",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }
                    val dateLabel = SimpleDateFormat("EEEE, d MMMM", Locale.ROOT).format(Date())
                    Text(
                        text = dateLabel,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (userName.isNotBlank()) userName.take(1).uppercase() else "৳",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        // --- Master Balance Card ---
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("home_balance_card"),
                shape = RoundedCornerShape(26.dp),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Brush.linearGradient(listOf(CashStart, CashEnd)))
                        .padding(20.dp)
                ) {
                    Text(
                        text = "৳",
                        fontSize = 140.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White.copy(alpha = 0.12f),
                        modifier = Modifier.align(Alignment.TopEnd)
                    )

                    Column {
                        Text(
                            text = BanglaUtils.tr("Balance", isBangla),
                            fontSize = 13.sp,
                            color = Color.White.copy(alpha = 0.9f)
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = (if (totalBalance < 0) "−" else "") + BanglaUtils.formatTaka(totalBalance, isBangla),
                            fontSize = 36.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Spacer(Modifier.height(6.dp))
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "↙ " + BanglaUtils.formatTaka(monthIncome, isBangla),
                                fontSize = 13.sp,
                                color = Color.White.copy(alpha = 0.95f),
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "↗ " + BanglaUtils.formatTaka(monthExpense, isBangla),
                                fontSize = 13.sp,
                                color = Color.White.copy(alpha = 0.95f),
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = BanglaUtils.tr("this month", isBangla),
                                fontSize = 13.sp,
                                color = Color.White.copy(alpha = 0.85f)
                            )
                        }
                        Spacer(Modifier.height(4.dp))
                        val todaySign = if (todayNet >= 0) "+" else "−"
                        Text(
                            text = "${BanglaUtils.tr("Today", isBangla)} $todaySign${BanglaUtils.formatTaka(todayNet, isBangla)}",
                            fontSize = 13.sp,
                            color = Color.White.copy(alpha = 0.9f)
                        )
                    }
                }
            }
        }

        // --- Natural Language Processing Input Card ---
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("nlp_input_card"),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Title with Gemini AI Badge
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "Smart AI Expense Logger",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f)
                        ) {
                            Text(
                                text = "Bangla & English",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    // Input Field Container
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                            .padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        OutlinedTextField(
                            value = inputQuery,
                            onValueChange = { inputQuery = it },
                            placeholder = {
                                Text(
                                    "Type e.g. lunch 250, rickshaw 60, salary 80k…",
                                    fontSize = 13.5.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                )
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("natural_input_field"),
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color.Transparent,
                                unfocusedBorderColor = Color.Transparent
                            ),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                            keyboardActions = KeyboardActions(onSend = {
                                if (inputQuery.isNotBlank() && !isAiParsing) {
                                    viewModel.submitNaturalInput(inputQuery)
                                    inputQuery = ""
                                }
                            })
                        )

                        // Clear Button if input not blank
                        if (inputQuery.isNotBlank()) {
                            IconButton(
                                onClick = { inputQuery = "" },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Clear,
                                    contentDescription = "Clear input",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        // Microphone Voice Input Button
                        IconButton(
                            onClick = {
                                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
                                    putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak in Bangla or English, e.g. lunch 250, chal 80")
                                }
                                try {
                                    speechLauncher.launch(intent)
                                } catch (e: Exception) {
                                    viewModel.showToast("Voice input unavailable")
                                }
                            },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Mic,
                                contentDescription = "Voice Dictation",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        // Send Action Button
                        IconButton(
                            onClick = {
                                if (inputQuery.isNotBlank() && !isAiParsing) {
                                    viewModel.submitNaturalInput(inputQuery)
                                    inputQuery = ""
                                }
                            },
                            enabled = !isAiParsing && inputQuery.isNotBlank(),
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(
                                    if (inputQuery.isNotBlank()) MaterialTheme.colorScheme.primary
                                    else MaterialTheme.colorScheme.primary.copy(alpha = 0.4f)
                                )
                                .testTag("natural_input_send_button")
                        ) {
                            if (isAiParsing) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    color = Color.White,
                                    strokeWidth = 2.dp
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Default.ArrowUpward,
                                    contentDescription = "Submit",
                                    tint = Color.White,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }

                    // Status / Tip
                    Text(
                        text = if (isAiParsing) "✨ Gemini AI is parsing in Bangla & English…"
                        else "Supports Bangla script (চা নাশতা ১২০), multipliers (80k), and wallets (bkash)",
                        fontSize = 11.5.sp,
                        color = if (isAiParsing) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = if (isAiParsing) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier.padding(start = 2.dp)
                    )

                    // Quick Example Prompt Chips
                    Text(
                        text = "Quick examples:",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    val samplePrompts = listOf(
                        "Lunch 250",
                        "চা নাশতা ১২০",
                        "Wifi bill 500 (bank)",
                        "Salary pelam 80k",
                        "চাল ৮০ টাকা (bkash), ডাল ১২০"
                    )
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(samplePrompts) { prompt ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                                    .clickable {
                                        inputQuery = prompt
                                        viewModel.submitNaturalInput(prompt)
                                        inputQuery = ""
                                    }
                                    .padding(horizontal = 9.dp, vertical = 5.dp)
                            ) {
                                Text(
                                    text = prompt,
                                    fontSize = 11.5.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }
        }

        // --- Action Chips ---
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    SuggestionChip(
                        onClick = { viewModel.openBazarMode() },
                        label = { Text("🛒 " + BanglaUtils.tr("Bazar mode", isBangla)) },
                        colors = SuggestionChipDefaults.suggestionChipColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant
                        ),
                        modifier = Modifier.testTag("bazar_mode_chip")
                    )
                }
                item {
                    SuggestionChip(
                        onClick = { viewModel.openPasteSms() },
                        label = { Text("📩 " + BanglaUtils.tr("Paste SMS", isBangla)) },
                        colors = SuggestionChipDefaults.suggestionChipColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant
                        ),
                        modifier = Modifier.testTag("paste_sms_chip")
                    )
                }
            }
        }

        // --- Budget Warnings Card ---
        if (budgetAlerts.isNotEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "⚠ " + BanglaUtils.tr("Budget alert", isBangla),
                            fontWeight = FontWeight.Bold,
                            color = ExpenseRed,
                            fontSize = 14.sp
                        )
                        Spacer(Modifier.height(6.dp))
                        for ((cat, spent, limit) in budgetAlerts) {
                            val pct = ((spent / limit) * 100).toInt()
                            val meta = CategoryRegistry.getCategory(cat)
                            Text(
                                text = "${meta.icon} $cat: $pct% of ${BanglaUtils.formatTaka(limit, isBangla)} used (${BanglaUtils.formatTaka(spent, isBangla)})",
                                fontSize = 12.5.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }

        // --- Unpaid Monthly Fixed Bills ---
        if (unpaidBills.isNotEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = BanglaUtils.tr("Monthly fixed", isBangla) + " · ${unpaidBills.size} " + BanglaUtils.tr("unpaid", isBangla),
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                        }
                        Spacer(Modifier.height(8.dp))
                        for (bill in unpaidBills) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = bill.title,
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 14.sp
                                    )
                                    Text(
                                        text = "${BanglaUtils.formatTaka(bill.amount, isBangla)} · day ${bill.day}",
                                        fontSize = 12.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Button(
                                    onClick = { viewModel.payFixedBill(bill) },
                                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.testTag("pay_bill_${bill.id}")
                                ) {
                                    Text(
                                        text = if (bill.type == "income") BanglaUtils.tr("Got it", isBangla) else BanglaUtils.tr("Pay", isBangla),
                                        fontSize = 13.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // --- Streak Card ---
        if (streakDays >= 2) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(text = "🔥", fontSize = 24.sp)
                        Column {
                            Text(
                                text = "$streakDays-day no-spend streak!",
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "Great financial control! Keep saving.",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        // --- Recent Transactions Section ---
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ReceiptLong,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = BanglaUtils.tr("Recent", isBangla),
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                }

                TextButton(
                    onClick = { viewModel.setScreen("history") },
                    modifier = Modifier.testTag("see_all_history_button")
                ) {
                    Text(
                        text = BanglaUtils.tr("See all", isBangla),
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        if (recentTransactions.isEmpty()) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(28.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(text = "📝", fontSize = 32.sp)
                            Text(
                                text = "No entries yet.",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Write in the box above or tap one of the quick examples!",
                                fontSize = 12.5.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        } else {
            items(recentTransactions, key = { it.id }) { item ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
                ) {
                    TransactionRow(
                        item = item,
                        isBangla = isBangla,
                        showDate = true,
                        onEdit = {
                            viewModel.openEditTransaction(
                                com.example.data.model.TransactionItem(
                                    id = item.id,
                                    type = item.type,
                                    title = item.title,
                                    category = item.category,
                                    amount = item.amount,
                                    wallet = item.wallet,
                                    timestamp = item.timestamp,
                                    note = item.note,
                                    imageUri = item.imageUri,
                                    isSalarySaved = item.isSalarySaved
                                )
                            )
                        },
                        onDelete = { viewModel.deleteTransaction(item.id) }
                    )
                }
            }
        }

        item { Spacer(Modifier.height(80.dp)) }
    }
}
