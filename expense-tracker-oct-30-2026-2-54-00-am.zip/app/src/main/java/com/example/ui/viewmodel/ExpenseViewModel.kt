package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.BudgetEntity
import com.example.data.local.DebtEntity
import com.example.data.local.FixedBillEntity
import com.example.data.local.SavingsGoalEntity
import com.example.data.local.TourEntity
import com.example.data.local.TransactionEntity
import com.example.data.local.WalletHistoryEntity
import com.example.data.model.CategoryBudget
import com.example.data.model.DebtItem
import com.example.data.model.DebtPayment
import com.example.data.model.FixedBill
import com.example.data.model.SavingsGoal
import com.example.data.ai.GeminiExpenseParserService
import com.example.data.model.TourExpense
import com.example.data.model.TourItem
import com.example.data.model.TransactionItem
import com.example.data.model.WalletHistory
import com.example.data.parser.SmartParser
import com.example.data.preferences.UserPreferencesManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class ExpenseViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val dao = db.appDao()
    val prefs = UserPreferencesManager(application)
    private val geminiService = GeminiExpenseParserService()

    private val _isAiParsing = MutableStateFlow(false)
    val isAiParsing: StateFlow<Boolean> = _isAiParsing.asStateFlow()

    // Raw flows from Database
    val transactions = dao.getAllTransactions().stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    val fixedBills = dao.getAllFixedBills().stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    val debts = dao.getAllDebts().stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    val savingsGoals = dao.getAllSavingsGoals().stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    val budgets = dao.getAllBudgets().stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    val tours = dao.getAllTours().stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    val walletHistory = dao.getWalletHistory().stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    // Navigation & UI State
    private val _currentScreen = MutableStateFlow("home")
    val currentScreen: StateFlow<String> = _currentScreen.asStateFlow()

    private val _planTab = MutableStateFlow("debt") // debt, goal, fx, bud, trip
    val planTab: StateFlow<String> = _planTab.asStateFlow()

    private val _insightsRange = MutableStateFlow("m") // m, 6m, y
    val insightsRange: StateFlow<String> = _insightsRange.asStateFlow()

    private val _insightsBreakdown = MutableStateFlow("Spent") // Spent, Earned
    val insightsBreakdown: StateFlow<String> = _insightsBreakdown.asStateFlow()

    // History Filters State
    private val _historyCalendar = MutableStateFlow(Calendar.getInstance())
    val historyCalendar: StateFlow<Calendar> = _historyCalendar.asStateFlow()

    private val _historySearchQuery = MutableStateFlow("")
    val historySearchQuery: StateFlow<String> = _historySearchQuery.asStateFlow()

    private val _historyCategoryFilter = MutableStateFlow("All")
    val historyCategoryFilter: StateFlow<String> = _historyCategoryFilter.asStateFlow()

    private val _historyWalletFilter = MutableStateFlow("")
    val historyWalletFilter: StateFlow<String> = _historyWalletFilter.asStateFlow()

    private val _historyMinAmount = MutableStateFlow<Double?>(null)
    val historyMinAmount: StateFlow<Double?> = _historyMinAmount.asStateFlow()

    private val _historyMaxAmount = MutableStateFlow<Double?>(null)
    val historyMaxAmount: StateFlow<Double?> = _historyMaxAmount.asStateFlow()

    private val _historyDateFrom = MutableStateFlow<String?>(null)
    val historyDateFrom: StateFlow<String?> = _historyDateFrom.asStateFlow()

    private val _historyDateTo = MutableStateFlow<String?>(null)
    val historyDateTo: StateFlow<String?> = _historyDateTo.asStateFlow()

    private val _isHistoryFilterExpanded = MutableStateFlow(false)
    val isHistoryFilterExpanded: StateFlow<Boolean> = _isHistoryFilterExpanded.asStateFlow()

    // Dialogs / Overlays
    private val _pendingReview = MutableStateFlow<List<TransactionItem>?>(null)
    val pendingReview: StateFlow<List<TransactionItem>?> = _pendingReview.asStateFlow()

    private val _isBazarModeOpen = MutableStateFlow(false)
    val isBazarModeOpen: StateFlow<Boolean> = _isBazarModeOpen.asStateFlow()

    private val _bazarItems = MutableStateFlow<List<TransactionItem>>(emptyList())
    val bazarItems: StateFlow<List<TransactionItem>> = _bazarItems.asStateFlow()

    private val _isPasteSmsOpen = MutableStateFlow(false)
    val isPasteSmsOpen: StateFlow<Boolean> = _isPasteSmsOpen.asStateFlow()

    private val _editingTransaction = MutableStateFlow<TransactionItem?>(null)
    val editingTransaction: StateFlow<TransactionItem?> = _editingTransaction.asStateFlow()

    private val _walletActionSheet = MutableStateFlow<String?>(null) // "abl", "sbl", "wt", "wa"
    val walletActionSheet: StateFlow<String?> = _walletActionSheet.asStateFlow()

    private val _activeTourId = MutableStateFlow<Long?>(null)
    val activeTourId: StateFlow<Long?> = _activeTourId.asStateFlow()

    private val _isLocked = MutableStateFlow(prefs.pin.value.isNotBlank())
    val isLocked: StateFlow<Boolean> = _isLocked.asStateFlow()

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage: StateFlow<String?> = _toastMessage.asStateFlow()

    private var undoAction: (() -> Unit)? = null

    init {
        checkAndApplySalaryAutoSave()
    }

    fun setScreen(screen: String) {
        _currentScreen.value = screen
    }

    fun setPlanTab(tab: String) {
        _planTab.value = tab
    }

    fun setInsightsRange(range: String) {
        _insightsRange.value = range
    }

    fun setInsightsBreakdown(breakdown: String) {
        _insightsBreakdown.value = breakdown
    }

    fun unlockApp(pin: String): Boolean {
        if (pin == prefs.pin.value) {
            _isLocked.value = false
            return true
        }
        return false
    }

    fun lockApp() {
        if (prefs.pin.value.isNotBlank()) {
            _isLocked.value = true
        }
    }

    fun showToast(msg: String, undo: (() -> Unit)? = null) {
        _toastMessage.value = msg
        undoAction = undo
    }

    fun clearToast() {
        _toastMessage.value = null
        undoAction = null
    }

    fun triggerUndo() {
        undoAction?.invoke()
        clearToast()
    }

    // --- Transactions Operations ---

    fun submitNaturalInput(text: String, useAi: Boolean = true) {
        if (text.isBlank()) return

        viewModelScope.launch {
            var parsed: List<TransactionItem> = emptyList()

            if (useAi) {
                _isAiParsing.value = true
                try {
                    val aiResult = geminiService.parseExpenseInput(text, prefs.wallets.value)
                    if (aiResult.isSuccess && !aiResult.getOrNull().isNullOrEmpty()) {
                        parsed = aiResult.getOrNull()!!
                    }
                } catch (e: Exception) {
                    // Falls back to SmartParser below
                } finally {
                    _isAiParsing.value = false
                }
            }

            // Fallback to local rule-based smart parser if AI returned empty or failed
            if (parsed.isEmpty()) {
                parsed = SmartParser.parseInput(
                    input = text,
                    availableWallets = prefs.wallets.value,
                    learnedCategories = prefs.getLearnedCategories()
                )
            }

            if (parsed.isEmpty()) {
                showToast("No amount found. Try: lunch 80, wifi 500")
                return@launch
            }

            if (prefs.reviewBeforeSave.value) {
                _pendingReview.value = parsed
            } else {
                saveTransactions(parsed)
            }
        }
    }

    fun saveTransactions(items: List<TransactionItem>) {
        viewModelScope.launch {
            val entities = items.map { item ->
                TransactionEntity(
                    id = item.id,
                    type = item.type,
                    title = item.title,
                    category = item.category,
                    amount = item.amount,
                    wallet = item.wallet,
                    timestamp = item.timestamp,
                    note = item.note,
                    imageUri = item.imageUri,
                    isSalarySaved = item.isSalarySaved
                )
            }
            dao.insertTransactions(entities)
            _pendingReview.value = null
            showToast(
                if (items.size > 1) "${items.size} entries saved" else "Saved ${items.first().title}"
            ) {
                viewModelScope.launch {
                    entities.forEach { dao.deleteTransaction(it.id) }
                }
            }
            checkAndApplySalaryAutoSave()
        }
    }

    fun deleteTransaction(id: Long) {
        viewModelScope.launch {
            val existing = transactions.value.find { it.id == id }
            dao.deleteTransaction(id)
            if (existing != null) {
                showToast("Deleted ${existing.title}") {
                    viewModelScope.launch { dao.insertTransaction(existing) }
                }
            }
        }
    }

    fun updateTransaction(item: TransactionItem) {
        viewModelScope.launch {
            val entity = TransactionEntity(
                id = item.id,
                type = item.type,
                title = item.title,
                category = item.category,
                amount = item.amount,
                wallet = item.wallet,
                timestamp = item.timestamp,
                note = item.note,
                imageUri = item.imageUri,
                isSalarySaved = item.isSalarySaved
            )
            dao.updateTransaction(entity)
            prefs.saveLearnedCategory(item.title, item.category, item.type)
            _editingTransaction.value = null
            showToast("Updated ${item.title}")
        }
    }

    fun openEditTransaction(item: TransactionItem) {
        _editingTransaction.value = item
    }

    fun closeEditTransaction() {
        _editingTransaction.value = null
    }

    fun dismissReview() {
        _pendingReview.value = null
    }

    // --- Bazar Mode ---

    fun openBazarMode() {
        _bazarItems.value = emptyList()
        _isBazarModeOpen.value = true
    }

    fun closeBazarMode() {
        _isBazarModeOpen.value = false
        _bazarItems.value = emptyList()
    }

    fun addBazarInput(text: String) {
        val parsed = SmartParser.parseInput(text, prefs.wallets.value, prefs.getLearnedCategories())
        if (parsed.isEmpty()) {
            showToast("No amount found. Try: chal 80")
            return
        }
        val current = _bazarItems.value.toMutableList()
        for (item in parsed) {
            val groc = if (item.category == "Other") item.copy(category = "Groceries") else item
            current.add(groc)
        }
        _bazarItems.value = current
    }

    fun removeBazarItem(index: Int) {
        val current = _bazarItems.value.toMutableList()
        if (index in current.indices) {
            current.removeAt(index)
            _bazarItems.value = current
        }
    }

    fun saveBazarItems() {
        val items = _bazarItems.value
        if (items.isEmpty()) return
        saveTransactions(items)
        closeBazarMode()
    }

    // --- Paste SMS Mode ---

    fun openPasteSms() {
        _isPasteSmsOpen.value = true
    }

    fun closePasteSms() {
        _isPasteSmsOpen.value = false
    }

    fun processPasteSms(text: String) {
        val parsed = SmartParser.parseSms(text)
        if (parsed.isEmpty()) {
            showToast("No amount found in SMS")
            return
        }
        _isPasteSmsOpen.value = false
        _pendingReview.value = parsed
    }

    // --- Wallets Management ---

    fun openWalletAction(action: String) {
        _walletActionSheet.value = action
    }

    fun closeWalletAction() {
        _walletActionSheet.value = null
    }

    fun getWalletBalance(wallet: String): Double {
        val txs = transactions.value
        val income = txs.filter { it.wallet == wallet && it.type == "income" }.sumOf { it.amount }
        val expense = txs.filter { it.wallet == wallet && it.type == "expense" }.sumOf { it.amount }
        val offset = prefs.walletOffsets.value[wallet] ?: 0.0

        val transfers = walletHistory.value
        val transferIn = transfers.filter { it.kind == "transfer" && it.targetWallet == wallet }.sumOf { it.amount }
        val transferOut = transfers.filter { it.kind == "transfer" && it.wallet == wallet }.sumOf { it.amount }

        return income - expense + offset + transferIn - transferOut
    }

    fun getTotalBalance(): Double {
        return prefs.wallets.value.sumOf { getWalletBalance(it) }
    }

    fun setWalletBalance(wallet: String, targetBalance: Double) {
        val current = getWalletBalance(wallet)
        val delta = targetBalance - current
        prefs.addWalletOffset(wallet, delta)

        viewModelScope.launch {
            dao.insertWalletHistory(
                WalletHistoryEntity(
                    id = System.currentTimeMillis(),
                    timestamp = System.currentTimeMillis(),
                    kind = "set",
                    wallet = wallet,
                    targetWallet = null,
                    amount = targetBalance,
                    prevBalance = current
                )
            )
        }
        closeWalletAction()
        showToast("$wallet balance set")
    }

    fun addBalanceToWallet(wallet: String, amount: Double) {
        prefs.addWalletOffset(wallet, amount)
        viewModelScope.launch {
            dao.insertWalletHistory(
                WalletHistoryEntity(
                    id = System.currentTimeMillis(),
                    timestamp = System.currentTimeMillis(),
                    kind = "add",
                    wallet = wallet,
                    targetWallet = null,
                    amount = amount,
                    prevBalance = null
                )
            )
        }
        closeWalletAction()
        showToast("Added to $wallet")
    }

    fun transferBetweenWallets(from: String, to: String, amount: Double) {
        if (from == to || amount <= 0.0) {
            showToast("Select different wallets and valid amount")
            return
        }
        viewModelScope.launch {
            dao.insertWalletHistory(
                WalletHistoryEntity(
                    id = System.currentTimeMillis(),
                    timestamp = System.currentTimeMillis(),
                    kind = "transfer",
                    wallet = from,
                    targetWallet = to,
                    amount = amount,
                    prevBalance = null
                )
            )
        }
        closeWalletAction()
        showToast("Transferred from $from to $to")
    }

    fun addNewWallet(name: String) {
        val trimmed = name.trim().take(16)
        if (trimmed.isNotBlank()) {
            prefs.addWallet(trimmed)
            closeWalletAction()
            showToast("Wallet $trimmed added")
        }
    }

    fun deleteWallet(name: String) {
        if (name == "Cash") return
        prefs.removeWallet(name)
        showToast("Wallet $name removed")
    }

    // --- Monthly Fixed Bills ---

    fun addFixedBill(title: String, amount: Double, day: Int, category: String, type: String) {
        viewModelScope.launch {
            dao.insertFixedBill(
                FixedBillEntity(
                    id = System.currentTimeMillis(),
                    title = title.replaceFirstChar { it.uppercase() },
                    amount = amount,
                    day = day.coerceIn(1, 31),
                    category = category,
                    type = type,
                    paidMonth = null
                )
            )
            showToast("Bill $title added")
        }
    }

    fun payFixedBill(bill: FixedBillEntity) {
        viewModelScope.launch {
            val cal = Calendar.getInstance()
            val currentYearMonth = "${cal.get(Calendar.YEAR)}-${cal.get(Calendar.MONTH)}"

            // Add transaction
            dao.insertTransaction(
                TransactionEntity(
                    id = System.currentTimeMillis(),
                    type = bill.type,
                    title = bill.title,
                    category = bill.category,
                    amount = bill.amount,
                    wallet = "Cash",
                    timestamp = System.currentTimeMillis(),
                    note = "Monthly bill",
                    imageUri = null,
                    isSalarySaved = false
                )
            )
            // Update bill paid month
            dao.updateFixedBill(bill.copy(paidMonth = currentYearMonth))
            showToast("Paid ${bill.title}")
        }
    }

    fun deleteFixedBill(id: Long) {
        viewModelScope.launch {
            dao.deleteFixedBill(id)
            showToast("Bill removed")
        }
    }

    // --- Debts ---

    fun addDebt(who: String, total: Double, direction: String, date: String) {
        viewModelScope.launch {
            dao.insertDebt(
                DebtEntity(
                    id = System.currentTimeMillis(),
                    who = who.trim(),
                    total = total,
                    direction = direction,
                    date = date,
                    paymentsJson = "[]"
                )
            )
            showToast("Debt record added")
        }
    }

    fun addDebtPayment(debt: DebtEntity, amount: Double, date: String) {
        viewModelScope.launch {
            val array = try { JSONArray(debt.paymentsJson) } catch (e: Exception) { JSONArray() }
            val obj = JSONObject()
            obj.put("amt", amount)
            obj.put("date", date)
            array.put(obj)

            dao.updateDebt(debt.copy(paymentsJson = array.toString()))

            // Log corresponding transaction
            dao.insertTransaction(
                TransactionEntity(
                    id = System.currentTimeMillis(),
                    type = if (debt.direction == "b") "expense" else "income",
                    title = debt.who,
                    category = "Debt",
                    amount = amount,
                    wallet = "Cash",
                    timestamp = System.currentTimeMillis(),
                    note = "Debt payment",
                    imageUri = null,
                    isSalarySaved = false
                )
            )
            showToast("Payment recorded")
        }
    }

    fun deleteDebt(id: Long) {
        viewModelScope.launch {
            dao.deleteDebt(id)
            showToast("Debt deleted")
        }
    }

    // --- Savings Goals ---

    fun addSavingsGoal(title: String, target: Double) {
        viewModelScope.launch {
            dao.insertSavingsGoal(
                SavingsGoalEntity(
                    id = System.currentTimeMillis(),
                    title = title.trim(),
                    target = target,
                    paymentsJson = "[]"
                )
            )
            showToast("Goal $title added")
        }
    }

    fun contributeSavingsGoal(goal: SavingsGoalEntity, amount: Double) {
        viewModelScope.launch {
            val array = try { JSONArray(goal.paymentsJson) } catch (e: Exception) { JSONArray() }
            val obj = JSONObject()
            obj.put("amt", amount)
            obj.put("date", SimpleDateFormat("yyyy-MM-dd", Locale.ROOT).format(Date()))
            array.put(obj)

            dao.updateSavingsGoal(goal.copy(paymentsJson = array.toString()))

            dao.insertTransaction(
                TransactionEntity(
                    id = System.currentTimeMillis(),
                    type = "expense",
                    title = goal.title,
                    category = "Savings",
                    amount = amount,
                    wallet = "Cash",
                    timestamp = System.currentTimeMillis(),
                    note = "Goal contribution",
                    imageUri = null,
                    isSalarySaved = false
                )
            )
            showToast("Saved for ${goal.title}")
        }
    }

    fun deleteSavingsGoal(id: Long) {
        viewModelScope.launch {
            dao.deleteSavingsGoal(id)
            showToast("Goal deleted")
        }
    }

    // --- Budgets ---

    fun setBudget(category: String, limit: Double) {
        viewModelScope.launch {
            dao.insertBudget(BudgetEntity(category = category, limitAmount = limit))
            showToast("Budget set for $category")
        }
    }

    fun deleteBudget(category: String) {
        viewModelScope.launch {
            dao.deleteBudget(category)
            showToast("Budget removed")
        }
    }

    // --- Tours ---

    fun openTourDetail(id: Long) {
        _activeTourId.value = id
    }

    fun closeTourDetail() {
        _activeTourId.value = null
    }

    fun createTour(name: String, budget: Double, friends: List<String>) {
        viewModelScope.launch {
            val people = mutableListOf("Me")
            for (f in friends) {
                val tr = f.trim()
                if (tr.isNotBlank() && tr.lowercase() != "me" && !people.contains(tr)) {
                    people.add(tr)
                }
            }
            val peopleArray = JSONArray()
            people.forEach { peopleArray.put(it) }

            dao.insertTour(
                TourEntity(
                    id = System.currentTimeMillis(),
                    name = name.trim(),
                    budget = budget,
                    peopleJson = peopleArray.toString(),
                    expensesJson = "[]",
                    addedToBalance = 0.0
                )
            )
            showToast("Tour $name created")
        }
    }

    fun addTourExpense(tour: TourEntity, title: String, amount: Double, category: String, paidBy: String) {
        viewModelScope.launch {
            val array = try { JSONArray(tour.expensesJson) } catch (e: Exception) { JSONArray() }
            val obj = JSONObject()
            obj.put("id", System.currentTimeMillis())
            obj.put("title", title)
            obj.put("amt", amount)
            obj.put("cat", category)
            obj.put("by", paidBy)
            obj.put("date", SimpleDateFormat("yyyy-MM-dd", Locale.ROOT).format(Date()))
            array.put(obj)

            dao.updateTour(tour.copy(expensesJson = array.toString()))
            showToast("Expense added")
        }
    }

    fun deleteTourExpense(tour: TourEntity, expenseId: Long) {
        viewModelScope.launch {
            val array = try { JSONArray(tour.expensesJson) } catch (e: Exception) { JSONArray() }
            val newArray = JSONArray()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                if (obj.optLong("id") != expenseId) {
                    newArray.put(obj)
                }
            }
            dao.updateTour(tour.copy(expensesJson = newArray.toString()))
            showToast("Expense deleted")
        }
    }

    fun addMyTourShareToBalance(tour: TourEntity) {
        viewModelScope.launch {
            val expenses = parseTourExpenses(tour.expensesJson)
            val total = expenses.sumOf { it.amount }
            val people = parseTourPeople(tour.peopleJson)
            if (people.isEmpty()) return@launch
            val perPerson = total / people.size
            val remainingToAdd = perPerson - tour.addedToBalance

            if (remainingToAdd > 0) {
                dao.insertTransaction(
                    TransactionEntity(
                        id = System.currentTimeMillis(),
                        type = "expense",
                        title = tour.name,
                        category = "Travel",
                        amount = remainingToAdd,
                        wallet = "Cash",
                        timestamp = System.currentTimeMillis(),
                        note = "Tour share",
                        imageUri = null,
                        isSalarySaved = false
                    )
                )
                dao.updateTour(tour.copy(addedToBalance = tour.addedToBalance + remainingToAdd))
                showToast("Added tour share to balance")
            } else {
                showToast("Already added to balance")
            }
        }
    }

    fun deleteTour(id: Long) {
        viewModelScope.launch {
            dao.deleteTour(id)
            _activeTourId.value = null
            showToast("Tour deleted")
        }
    }

    // Helper functions for Tour parsing & Settlement algorithm
    fun parseTourPeople(jsonStr: String): List<String> {
        return try {
            val array = JSONArray(jsonStr)
            val list = mutableListOf<String>()
            for (i in 0 until array.length()) list.add(array.getString(i))
            if (list.isEmpty()) listOf("Me") else list
        } catch (e: Exception) {
            listOf("Me")
        }
    }

    fun parseTourExpenses(jsonStr: String): List<TourExpense> {
        return try {
            val array = JSONArray(jsonStr)
            val list = mutableListOf<TourExpense>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    TourExpense(
                        id = obj.optLong("id", System.currentTimeMillis()),
                        title = obj.optString("title", ""),
                        category = obj.optString("cat", "Other"),
                        amount = obj.optDouble("amt", 0.0),
                        paidBy = obj.optString("by", "Me"),
                        date = obj.optString("date", "")
                    )
                )
            }
            list
        } catch (e: Exception) {
            emptyList()
        }
    }

    /**
     * Computes the settlement matrix ("Who pays whom how much")
     */
    fun calculateTourSettlement(people: List<String>, expenses: List<TourExpense>): List<String> {
        if (people.size <= 1 || expenses.isEmpty()) return emptyList()
        val total = expenses.sumOf { it.amount }
        val perPerson = total / people.size

        val paidMap = people.associateWith { 0.0 }.toMutableMap()
        for (e in expenses) {
            paidMap[e.paidBy] = (paidMap[e.paidBy] ?: 0.0) + e.amount
        }

        val debtors = mutableListOf<Pair<String, Double>>() // balance < 0
        val creditors = mutableListOf<Pair<String, Double>>() // balance > 0

        for (p in people) {
            val net = (paidMap[p] ?: 0.0) - perPerson
            if (net < -0.5) debtors.add(Pair(p, -net))
            else if (net > 0.5) creditors.add(Pair(p, net))
        }

        debtors.sortByDescending { it.second }
        creditors.sortByDescending { it.second }

        val settlements = mutableListOf<String>()
        var i = 0
        var j = 0
        val dList = debtors.map { it.second }.toMutableList()
        val cList = creditors.map { it.second }.toMutableList()

        while (i < debtors.size && j < creditors.size) {
            val payAmt = Math.min(dList[i], cList[j])
            settlements.add("${debtors[i].first} pays ${creditors[j].first}: ৳${Math.round(payAmt)}")
            dList[i] -= payAmt
            cList[j] -= payAmt
            if (dList[i] < 0.5) i++
            if (cList[j] < 0.5) j++
        }

        return settlements
    }

    // --- History Navigation & Filters ---

    fun changeHistoryMonth(delta: Int) {
        val cal = _historyCalendar.value.clone() as Calendar
        cal.add(Calendar.MONTH, delta)
        _historyCalendar.value = cal
    }

    fun setHistorySearchQuery(q: String) {
        _historySearchQuery.value = q
    }

    fun setHistoryCategoryFilter(cat: String) {
        _historyCategoryFilter.value = cat
    }

    fun setHistoryWalletFilter(wallet: String) {
        _historyWalletFilter.value = wallet
    }

    fun setHistoryFilters(min: Double?, max: Double?, from: String?, to: String?) {
        _historyMinAmount.value = min
        _historyMaxAmount.value = max
        _historyDateFrom.value = from
        _historyDateTo.value = to
    }

    fun toggleHistoryFilterExpanded() {
        _isHistoryFilterExpanded.value = !_isHistoryFilterExpanded.value
    }

    fun clearHistoryFilters() {
        _historyMinAmount.value = null
        _historyMaxAmount.value = null
        _historyDateFrom.value = null
        _historyDateTo.value = null
        _historyCategoryFilter.value = "All"
        _historyWalletFilter.value = ""
        _isHistoryFilterExpanded.value = false
    }

    // --- Auto Salary Save & Recurring Bills check ---

    private fun checkAndApplySalaryAutoSave() {
        val autoSavePercent = prefs.salaryAutoSave.value
        if (autoSavePercent <= 0) return

        viewModelScope.launch {
            val list = dao.getAllTransactions()
            // Handled when new salary transactions are inserted
        }
    }

    // --- Clear All Data & Backup ---

    fun clearAllData() {
        viewModelScope.launch {
            dao.clearAllTransactions()
            dao.clearAllFixedBills()
            dao.clearAllDebts()
            dao.clearAllSavingsGoals()
            dao.clearAllBudgets()
            dao.clearAllTours()
            dao.clearAllWalletHistory()
            prefs.clearAllPreferences()
            showToast("All data deleted")
        }
    }

    fun exportCsv(): String {
        val txs = transactions.value
        val sb = StringBuilder()
        sb.append("Date,Time,Title,Type,Category,Wallet,Amount,Note\n")
        val df = SimpleDateFormat("yyyy-MM-dd", Locale.ROOT)
        val tf = SimpleDateFormat("HH:mm", Locale.ROOT)

        for (tx in txs) {
            val d = Date(tx.timestamp)
            sb.append("${df.format(d)},${tf.format(d)},\"${tx.title.replace("\"", "\"\"")}\",${tx.type},${tx.category},${tx.wallet},${tx.amount},\"${tx.note.replace("\"", "\"\"")}\"\n")
        }
        return sb.toString()
    }

    fun importCsv(csvContent: String): Int {
        val lines = csvContent.lines().filter { it.isNotBlank() }
        if (lines.size < 2) return 0

        val header = lines[0].split(",").map { it.trim().lowercase() }
        val dateIdx = header.indexOfFirst { it.contains("date") || it.contains("time") }
        val titleIdx = header.indexOfFirst { it.contains("title") || it.contains("desc") || it.contains("name") }
        val typeIdx = header.indexOfFirst { it.contains("type") }
        val catIdx = header.indexOfFirst { it.contains("cat") }
        val walIdx = header.indexOfFirst { it.contains("wal") }
        val amtIdx = header.indexOfFirst { it.contains("amount") || it.contains("amt") || it.contains("price") }
        val noteIdx = header.indexOfFirst { it.contains("note") }

        if (amtIdx < 0) return 0

        val imported = mutableListOf<TransactionEntity>()
        val existingIds = transactions.value.map { "${it.timestamp}|${it.amount}|${it.title.lowercase()}" }.toSet()

        for (i in 1 until lines.size) {
            val row = parseCsvLine(lines[i])
            if (row.size <= amtIdx) continue
            val rawAmt = row[amtIdx].replace(Regex("[^0-9.]"), "").toDoubleOrNull() ?: continue
            if (rawAmt <= 0.0) continue

            val title = if (titleIdx in row.indices && row[titleIdx].isNotBlank()) row[titleIdx] else "Imported"
            val type = if (typeIdx in row.indices && row[typeIdx].lowercase().contains("inc")) "income" else "expense"
            val cat = if (catIdx in row.indices && row[catIdx].isNotBlank()) row[catIdx] else if (type == "income") "Income" else "Other"
            val wal = if (walIdx in row.indices && row[walIdx].isNotBlank()) row[walIdx] else "Cash"
            val note = if (noteIdx in row.indices) row[noteIdx] else ""

            val timestamp = System.currentTimeMillis() + i
            val key = "$timestamp|$rawAmt|${title.lowercase()}"
            if (!existingIds.contains(key)) {
                imported.add(
                    TransactionEntity(
                        id = timestamp,
                        type = type,
                        title = title,
                        category = cat,
                        amount = rawAmt,
                        wallet = wal,
                        timestamp = timestamp,
                        note = note,
                        imageUri = null,
                        isSalarySaved = false
                    )
                )
            }
        }

        if (imported.isNotEmpty()) {
            viewModelScope.launch {
                dao.insertTransactions(imported)
                showToast("Imported ${imported.size} entries")
            }
        }
        return imported.size
    }

    private fun parseCsvLine(line: String): List<String> {
        val result = mutableListOf<String>()
        var inQuotes = false
        val sb = StringBuilder()
        for (char in line) {
            when {
                char == '\"' -> inQuotes = !inQuotes
                char == ',' && !inQuotes -> {
                    result.add(sb.toString().trim())
                    sb.clear()
                }
                else -> sb.append(char)
            }
        }
        result.add(sb.toString().trim())
        return result
    }
}
