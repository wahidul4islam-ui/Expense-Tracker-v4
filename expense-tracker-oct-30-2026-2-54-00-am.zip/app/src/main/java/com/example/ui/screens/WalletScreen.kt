package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CompareArrows
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SuggestionChip
import androidx.compose.material3.SuggestionChipDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.parser.BanglaUtils
import com.example.ui.components.WalletCard
import com.example.ui.viewmodel.ExpenseViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun WalletScreen(
    viewModel: ExpenseViewModel,
    modifier: Modifier = Modifier
) {
    val wallets by viewModel.prefs.wallets.collectAsState()
    val userName by viewModel.prefs.userName.collectAsState()
    val isBangla = viewModel.prefs.language.collectAsState().value == "bn"
    val walletHistory by viewModel.walletHistory.collectAsState()

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(Modifier.height(8.dp))
            Text(
                text = BanglaUtils.tr("Wallets", isBangla),
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
        }

        // --- Wallet Cards List ---
        items(wallets) { walletName ->
            val balance = viewModel.getWalletBalance(walletName)
            WalletCard(
                walletName = walletName,
                balance = balance,
                ownerName = userName,
                isBangla = isBangla
            )
        }

        // --- Manage Wallets Section ---
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("manage_wallets_card"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = BanglaUtils.tr("Manage wallets", isBangla),
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                    Spacer(Modifier.height(10.dp))

                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        item {
                            SuggestionChip(
                                onClick = { viewModel.openWalletAction("abl") },
                                label = { Text("＋ " + BanglaUtils.tr("Add balance", isBangla)) },
                                colors = SuggestionChipDefaults.suggestionChipColors(
                                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                                ),
                                modifier = Modifier.testTag("action_add_balance")
                            )
                        }
                        item {
                            SuggestionChip(
                                onClick = { viewModel.openWalletAction("sbl") },
                                label = { Text("✏ " + BanglaUtils.tr("Set balance", isBangla)) },
                                colors = SuggestionChipDefaults.suggestionChipColors(
                                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                                ),
                                modifier = Modifier.testTag("action_set_balance")
                            )
                        }
                        item {
                            SuggestionChip(
                                onClick = { viewModel.openWalletAction("wt") },
                                label = { Text("⇄ " + BanglaUtils.tr("Transfer", isBangla)) },
                                colors = SuggestionChipDefaults.suggestionChipColors(
                                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                                ),
                                modifier = Modifier.testTag("action_transfer")
                            )
                        }
                        item {
                            SuggestionChip(
                                onClick = { viewModel.openWalletAction("wa") },
                                label = { Text("＋ " + BanglaUtils.tr("Add wallet", isBangla)) },
                                colors = SuggestionChipDefaults.suggestionChipColors(
                                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                                ),
                                modifier = Modifier.testTag("action_new_wallet")
                            )
                        }
                    }

                    Spacer(Modifier.height(14.dp))
                    Text(
                        text = "Wallet history",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.height(6.dp))

                    if (walletHistory.isEmpty()) {
                        Text(
                            text = "Transfers and balance changes will be listed here.",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                        )
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            for (item in walletHistory.take(8)) {
                                val dateStr = SimpleDateFormat("d MMM, h:mm a", Locale.ROOT).format(Date(item.timestamp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        val label = when (item.kind) {
                                            "transfer" -> "↔ ${item.wallet} → ${item.targetWallet}"
                                            "add" -> "➕ Added to ${item.wallet}"
                                            else -> "✏ ${item.wallet} set balance"
                                        }
                                        Text(text = label, fontWeight = FontWeight.Medium, fontSize = 13.5.sp)
                                        Text(text = dateStr, fontSize = 11.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    val prefix = if (item.kind == "add") "+" else ""
                                    Text(
                                        text = prefix + BanglaUtils.formatTaka(item.amount, isBangla),
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        item { Spacer(Modifier.height(80.dp)) }
    }
}
