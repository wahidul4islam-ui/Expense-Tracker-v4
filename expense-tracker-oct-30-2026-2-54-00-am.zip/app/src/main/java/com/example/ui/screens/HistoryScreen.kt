package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TransactionItem
import com.example.data.parser.BanglaUtils
import com.example.data.parser.CategoryRegistry
import com.example.ui.components.TransactionRow
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.IncomeGreen
import com.example.ui.viewmodel.ExpenseViewModel
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Composable
fun HistoryScreen(
    viewModel: ExpenseViewModel,
    modifier: Modifier = Modifier
) {
    val isBangla = viewModel.prefs.language.collectAsState().value == "bn"
    val transactions by viewModel.transactions.collectAsState()
    val wallets by viewModel.prefs.wallets.collectAsState()

    val historyCalendar by viewModel.historyCalendar.collectAsState()
    val searchQuery by viewModel.historySearchQuery.collectAsState()
    val categoryFilter by viewModel.historyCategoryFilter.collectAsState()
    val walletFilter by viewModel.historyWalletFilter.collectAsState()
    val minAmount by viewModel.historyMinAmount.collectAsState()
    val maxAmount by viewModel.historyMaxAmount.collectAsState()
    val isFilterExpanded by viewModel.isHistoryFilterExpanded.collectAsState()

    var minInput by remember(minAmount) { mutableStateOf(minAmount?.toString() ?: "") }
    var maxInput by remember(maxAmount) { mutableStateOf(maxAmount?.toString() ?: "") }

    val monthLabel = remember(historyCalendar) {
        SimpleDateFormat("MMMM yyyy", Locale.ROOT).format(historyCalendar.time)
    }

    // Filter transactions
    val filteredTransactions = remember(
        transactions, historyCalendar, searchQuery, categoryFilter, walletFilter, minAmount, maxAmount
    ) {
        val targetYear = historyCalendar.get(Calendar.YEAR)
        val targetMonth = historyCalendar.get(Calendar.MONTH)

        transactions.filter { tx ->
            val txCal = Calendar.getInstance().apply { timeInMillis = tx.timestamp }
            val inMonth = txCal.get(Calendar.YEAR) == targetYear && txCal.get(Calendar.MONTH) == targetMonth

            val matchesSearch = searchQuery.isBlank() ||
                    tx.title.contains(searchQuery, ignoreCase = true) ||
                    tx.category.contains(searchQuery, ignoreCase = true) ||
                    tx.note.contains(searchQuery, ignoreCase = true)

            val matchesCat = when (categoryFilter) {
                "All" -> true
                "Income" -> tx.type == "income"
                "Expenses" -> tx.type == "expense"
                else -> tx.category == categoryFilter
            }

            val matchesWallet = walletFilter.isBlank() || tx.wallet == walletFilter

            val matchesAmount = (minAmount == null || tx.amount >= minAmount!!) &&
                    (maxAmount == null || tx.amount <= maxAmount!!)

            inMonth && matchesSearch && matchesCat && matchesWallet && matchesAmount
        }
    }

    val totalIncome = filteredTransactions.filter { it.type == "income" }.sumOf { it.amount }
    val totalExpense = filteredTransactions.filter { it.type == "expense" }.sumOf { it.amount }
    val net = totalIncome - totalExpense

    // Group by Date
    val groupedByDate = remember(filteredTransactions) {
        val df = SimpleDateFormat("d MMMM yyyy", Locale.ROOT)
        filteredTransactions.groupBy { df.format(Date(it.timestamp)) }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Month selector
        item {
            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = monthLabel,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Row {
                    IconButton(
                        onClick = { viewModel.changeHistoryMonth(-1) },
                        modifier = Modifier.testTag("history_prev_month")
                    ) {
                        Icon(Icons.Default.ChevronLeft, contentDescription = "Previous Month")
                    }
                    IconButton(
                        onClick = { viewModel.changeHistoryMonth(1) },
                        modifier = Modifier.testTag("history_next_month")
                    ) {
                        Icon(Icons.Default.ChevronRight, contentDescription = "Next Month")
                    }
                }
            }

            // Summary row
            Row(
                modifier = Modifier.padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "↙ " + BanglaUtils.formatTaka(totalIncome, isBangla),
                    color = IncomeGreen,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.5.sp
                )
                Text(
                    text = "↗ " + BanglaUtils.formatTaka(totalExpense, isBangla),
                    color = ExpenseRed,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.5.sp
                )
                val netSign = if (net >= 0) "+" else "−"
                Text(
                    text = "net $netSign${BanglaUtils.formatTaka(net, isBangla)}",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 13.5.sp
                )
            }
        }

        // Search Input
        item {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { viewModel.setHistorySearchQuery(it) },
                placeholder = { Text(BanglaUtils.tr("Search entries", isBangla)) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("history_search_field"),
                shape = RoundedCornerShape(16.dp),
                singleLine = true
            )
        }

        // Filter Toggle and Filter Box
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = isFilterExpanded || minAmount != null || maxAmount != null,
                    onClick = { viewModel.toggleHistoryFilterExpanded() },
                    label = {
                        Text(
                            text = "⚙ " + BanglaUtils.tr("Filters", isBangla) +
                                    if (minAmount != null || maxAmount != null) " · on" else ""
                        )
                    },
                    modifier = Modifier.testTag("history_filter_toggle")
                )
                if (minAmount != null || maxAmount != null || searchQuery.isNotBlank() || categoryFilter != "All" || walletFilter.isNotBlank()) {
                    TextButton(onClick = {
                        viewModel.clearHistoryFilters()
                        viewModel.setHistorySearchQuery("")
                    }) {
                        Text(BanglaUtils.tr("Clear filters", isBangla))
                    }
                }
            }

            AnimatedVisibility(visible = isFilterExpanded) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = BanglaUtils.tr("Amount", isBangla),
                            fontWeight = FontWeight.Medium,
                            fontSize = 13.sp
                        )
                        Spacer(Modifier.height(4.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = minInput,
                                onValueChange = {
                                    minInput = it
                                    viewModel.setHistoryFilters(it.toDoubleOrNull(), maxAmount, null, null)
                                },
                                placeholder = { Text(BanglaUtils.tr("Min", isBangla)) },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp),
                                singleLine = true
                            )
                            OutlinedTextField(
                                value = maxInput,
                                onValueChange = {
                                    maxInput = it
                                    viewModel.setHistoryFilters(minAmount, it.toDoubleOrNull(), null, null)
                                },
                                placeholder = { Text(BanglaUtils.tr("Max", isBangla)) },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(12.dp),
                                singleLine = true
                            )
                        }
                    }
                }
            }
        }

        // Wallet Filter Chips
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    FilterChip(
                        selected = walletFilter.isBlank(),
                        onClick = { viewModel.setHistoryWalletFilter("") },
                        label = { Text("All wallets") }
                    )
                }
                items(wallets) { w ->
                    FilterChip(
                        selected = walletFilter == w,
                        onClick = { viewModel.setHistoryWalletFilter(if (walletFilter == w) "" else w) },
                        label = { Text(w) }
                    )
                }
            }
        }

        // Category Filter Chips
        item {
            val categoriesList = listOf("All", "Income", "Expenses") + CategoryRegistry.categories.keys.filter { it != "Salary" && it != "Income" }
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(categoriesList) { cat ->
                    FilterChip(
                        selected = categoryFilter == cat,
                        onClick = { viewModel.setHistoryCategoryFilter(cat) },
                        label = { Text(BanglaUtils.tr(cat, isBangla)) }
                    )
                }
            }
        }

        // Transaction Groups by Date
        if (filteredTransactions.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(40.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No entries for this view.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        } else {
            for ((dateHeader, txList) in groupedByDate) {
                item {
                    Text(
                        text = dateHeader,
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(top = 8.dp, bottom = 4.dp)
                    )
                }
                items(txList, key = { it.id }) { tx ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        TransactionRow(
                            item = tx,
                            isBangla = isBangla,
                            showDate = false,
                            onEdit = {
                                viewModel.openEditTransaction(
                                    TransactionItem(
                                        id = tx.id,
                                        type = tx.type,
                                        title = tx.title,
                                        category = tx.category,
                                        amount = tx.amount,
                                        wallet = tx.wallet,
                                        timestamp = tx.timestamp,
                                        note = tx.note,
                                        imageUri = tx.imageUri,
                                        isSalarySaved = tx.isSalarySaved
                                    )
                                )
                            },
                            onDelete = { viewModel.deleteTransaction(tx.id) }
                        )
                    }
                }
            }
        }

        item { Spacer(Modifier.height(80.dp)) }
    }
}
