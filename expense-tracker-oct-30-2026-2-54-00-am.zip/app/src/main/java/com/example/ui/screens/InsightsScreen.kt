package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.parser.BanglaUtils
import com.example.data.parser.CategoryRegistry
import com.example.ui.components.CategoryDonutChart
import com.example.ui.components.MilestoneProgressBar
import com.example.ui.components.PieChartVisualizer
import com.example.ui.theme.ExpenseRed
import com.example.ui.theme.IncomeGreen
import com.example.ui.viewmodel.ExpenseViewModel
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Composable
fun InsightsScreen(
    viewModel: ExpenseViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val isBangla = viewModel.prefs.language.collectAsState().value == "bn"
    val transactions by viewModel.transactions.collectAsState()
    val budgets by viewModel.budgets.collectAsState()
    val goals by viewModel.savingsGoals.collectAsState()

    val range by viewModel.insightsRange.collectAsState() // "m", "6m", "y"
    val breakdownMode by viewModel.insightsBreakdown.collectAsState() // "Spent", "Earned"

    val savingsRateGoal by viewModel.prefs.savingsRateGoal.collectAsState()
    val salaryAutoSave by viewModel.prefs.salaryAutoSave.collectAsState()

    var savingsRateInput by remember { mutableStateOf("") }
    var salaryAutoSaveInput by remember { mutableStateOf("") }

    val now = Calendar.getInstance()
    val currentMonthIdx = now.get(Calendar.YEAR) * 12 + now.get(Calendar.MONTH)

    // Filter transactions by range
    val rangeTransactions = remember(transactions, range) {
        transactions.filter { tx ->
            val c = Calendar.getInstance().apply { timeInMillis = tx.timestamp }
            val txMonthIdx = c.get(Calendar.YEAR) * 12 + c.get(Calendar.MONTH)
            val diff = currentMonthIdx - txMonthIdx
            when (range) {
                "m" -> diff == 0
                "6m" -> diff in 0..5
                "y" -> c.get(Calendar.YEAR) == now.get(Calendar.YEAR) && diff >= 0
                else -> true
            }
        }
    }

    val totalIncome = rangeTransactions.filter { it.type == "income" }.sumOf { it.amount }
    val totalExpense = rangeTransactions.filter { it.type == "expense" }.sumOf { it.amount }
    val totalSaved = totalIncome - totalExpense
    val savingsPercent = if (totalIncome > 0) Math.round((totalSaved / totalIncome) * 100).toInt() else 0

    // vs last month calculation
    val vsLastMonthText = remember(transactions) {
        val curExpenses = transactions.filter {
            val c = Calendar.getInstance().apply { timeInMillis = it.timestamp }
            (c.get(Calendar.YEAR) * 12 + c.get(Calendar.MONTH)) == currentMonthIdx && it.type == "expense"
        }
        val lastExpenses = transactions.filter {
            val c = Calendar.getInstance().apply { timeInMillis = it.timestamp }
            (c.get(Calendar.YEAR) * 12 + c.get(Calendar.MONTH)) == currentMonthIdx - 1 && it.type == "expense"
        }
        val curTotal = curExpenses.sumOf { it.amount }
        val lastTotal = lastExpenses.sumOf { it.amount }

        if (curTotal == 0.0 && lastTotal == 0.0) {
            "No spending records to compare."
        } else if (lastTotal == 0.0) {
            "Spending ${BanglaUtils.formatTaka(curTotal, isBangla)}. No spending last month to compare."
        } else {
            val diffPct = Math.round(((curTotal - lastTotal) / lastTotal) * 100).toInt()
            val direction = if (diffPct >= 0) "up" else "down"

            val curCats = curExpenses.groupBy { it.category }.mapValues { it.value.sumOf { t -> t.amount } }
            val lastCats = lastExpenses.groupBy { it.category }.mapValues { it.value.sumOf { t -> t.amount } }

            val biggestRise = curCats.map { (cat, amt) ->
                Pair(cat, amt - (lastCats[cat] ?: 0.0))
            }.maxByOrNull { it.second }

            buildString {
                append("Spending ${BanglaUtils.formatTaka(curTotal, isBangla)}, $direction ${Math.abs(diffPct)}% from ${BanglaUtils.formatTaka(lastTotal, isBangla)}.")
                if (biggestRise != null && biggestRise.second > 0) {
                    val meta = CategoryRegistry.getCategory(biggestRise.first)
                    append(" Biggest rise: ${meta.icon} ${biggestRise.first} (+${BanglaUtils.formatTaka(biggestRise.second, isBangla)}).")
                }
            }
        }
    }

    // Monthly Trend (last 6 months)
    val monthlyTrendData = remember(transactions) {
        val months = (5 downTo 0).map { offset ->
            val c = Calendar.getInstance()
            c.add(Calendar.MONTH, -offset)
            c
        }
        months.map { mCal ->
            val mKey = mCal.get(Calendar.YEAR) * 12 + mCal.get(Calendar.MONTH)
            val inMonth = transactions.filter {
                val c = Calendar.getInstance().apply { timeInMillis = it.timestamp }
                (c.get(Calendar.YEAR) * 12 + c.get(Calendar.MONTH)) == mKey
            }
            val inc = inMonth.filter { it.type == "income" }.sumOf { it.amount }
            val exp = inMonth.filter { it.type == "expense" }.sumOf { it.amount }
            val label = SimpleDateFormat("MMM", Locale.ROOT).format(mCal.time)
            Triple(label, inc, exp)
        }
    }
    val maxTrendVal = remember(monthlyTrendData) {
        monthlyTrendData.flatMap { listOf(it.second, it.third) }.maxOrNull()?.coerceAtLeast(1.0) ?: 1.0
    }

    // Category breakdown
    val categoryTotals = remember(rangeTransactions, breakdownMode) {
        val targetType = if (breakdownMode == "Spent") "expense" else "income"
        rangeTransactions.filter { it.type == targetType }
            .groupBy { it.category }
            .mapValues { it.value.sumOf { tx -> tx.amount } }
            .toList()
            .sortedByDescending { it.second }
    }
    val breakdownTotal = remember(categoryTotals) { categoryTotals.sumOf { it.second } }

    // Forecast
    val forecastText = remember(transactions) {
        val curExpenses = transactions.filter {
            val c = Calendar.getInstance().apply { timeInMillis = it.timestamp }
            (c.get(Calendar.YEAR) * 12 + c.get(Calendar.MONTH)) == currentMonthIdx && it.type == "expense"
        }.sumOf { it.amount }

        val dayOfMonth = now.get(Calendar.DAY_OF_MONTH)
        val daysInMonth = now.getActualMaximum(Calendar.DAY_OF_MONTH)
        val pacePerDay = if (dayOfMonth > 0) curExpenses / dayOfMonth else 0.0
        val projectedTotal = pacePerDay * daysInMonth
        val bal = viewModel.getTotalBalance()
        val daysLeft = if (pacePerDay > 0 && bal > 0) (bal / pacePerDay).toInt() else 0

        Pair(
            "At this pace you will spend ~${BanglaUtils.formatTaka(projectedTotal, isBangla)} this month (~${BanglaUtils.formatTaka(pacePerDay, isBangla)}/day)",
            if (bal > 0) "Balance lasts ~$daysLeft days ${if (daysLeft < (daysInMonth - dayOfMonth)) "⚠ may run out before month end" else "✓ enough for the month"}" else "No balance left"
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(Modifier.height(8.dp))
            Text(
                text = BanglaUtils.tr("Insights", isBangla),
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(Modifier.height(8.dp))

            // Timeframe Segmented Control
            SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                val ranges = listOf(
                    "m" to BanglaUtils.tr("Month", isBangla),
                    "6m" to BanglaUtils.tr("6 months", isBangla),
                    "y" to BanglaUtils.tr("This year", isBangla)
                )
                ranges.forEachIndexed { index, (rKey, rLabel) ->
                    SegmentedButton(
                        selected = range == rKey,
                        onClick = { viewModel.setInsightsRange(rKey) },
                        shape = SegmentedButtonDefaults.itemShape(index = index, count = ranges.size)
                    ) {
                        Text(rLabel, fontSize = 12.5.sp)
                    }
                }
            }
        }

        // --- Saved Card ---
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = BanglaUtils.tr("Saved", isBangla),
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val sign = if (totalSaved >= 0) "+" else "−"
                        Text(
                            text = "$sign${BanglaUtils.formatTaka(totalSaved, isBangla)}",
                            fontSize = 30.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (totalSaved >= 0) IncomeGreen else ExpenseRed
                        )
                        if (totalIncome > 0) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant)
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "$savingsPercent% saved",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "↙ ${BanglaUtils.formatTaka(totalIncome, isBangla)}    ↗ ${BanglaUtils.formatTaka(totalExpense, isBangla)}",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // --- vs Last Month Card ---
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = BanglaUtils.tr("vs last month", isBangla),
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = vsLastMonthText,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // --- Monthly Trend Dual Bar Chart ---
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = BanglaUtils.tr("Monthly trend", isBangla),
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("■ Income", color = IncomeGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text("■ Expenses", color = ExpenseRed, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(Modifier.height(14.dp))

                    // Bars Container
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(140.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.Bottom
                    ) {
                        for ((monthLabel, inc, exp) in monthlyTrendData) {
                            val incHeightPct = (inc / maxTrendVal).toFloat().coerceIn(0.04f, 1f)
                            val expHeightPct = (exp / maxTrendVal).toFloat().coerceIn(0.04f, 1f)

                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.Bottom,
                                modifier = Modifier.fillMaxHeight()
                            ) {
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(3.dp),
                                    verticalAlignment = Alignment.Bottom,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    // Income Bar
                                    Box(
                                        modifier = Modifier
                                            .width(12.dp)
                                            .fillMaxHeight(incHeightPct)
                                            .clip(RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp))
                                            .background(IncomeGreen)
                                    )
                                    // Expense Bar
                                    Box(
                                        modifier = Modifier
                                            .width(12.dp)
                                            .fillMaxHeight(expHeightPct)
                                            .clip(RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp))
                                            .background(ExpenseRed)
                                    )
                                }
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    text = monthLabel,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    Spacer(Modifier.height(6.dp))
                    Text(
                        text = "Peak ${BanglaUtils.formatShortTaka(maxTrendVal, isBangla)}",
                        fontSize = 11.5.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // --- Category Breakdown Section ---
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = BanglaUtils.tr("By category", isBangla),
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        FilterChip(
                            selected = breakdownMode == "Spent",
                            onClick = { viewModel.setInsightsBreakdown("Spent") },
                            label = { Text(BanglaUtils.tr("Spent", isBangla)) }
                        )
                        FilterChip(
                            selected = breakdownMode == "Earned",
                            onClick = { viewModel.setInsightsBreakdown("Earned") },
                            label = { Text(BanglaUtils.tr("Earned", isBangla)) }
                        )
                    }
                }

                PieChartVisualizer(
                    categoryTotals = categoryTotals,
                    totalAmount = breakdownTotal,
                    isBangla = isBangla
                )
            }
        }

        // --- Forecast Card ---
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(text = "📈 Forecast", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(Modifier.height(4.dp))
                    Text(text = forecastText.first, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurface)
                    Spacer(Modifier.height(2.dp))
                    Text(text = forecastText.second, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }

        // --- Badges & Achievements ---
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(text = "🏅 Badges", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(Modifier.height(8.dp))
                    val has50 = transactions.size >= 50
                    val has20PctSaved = savingsPercent >= 20
                    val hasGoalComplete = goals.any { g ->
                        val pd = try {
                            val arr = org.json.JSONArray(g.paymentsJson)
                            var s = 0.0
                            for (i in 0 until arr.length()) s += arr.getJSONObject(i).optDouble("amt", 0.0)
                            s
                        } catch (e: Exception) { 0.0 }
                        pd >= g.target
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        BadgeChip("✍ 50+ entries", isUnlocked = has50)
                        BadgeChip("💰 20% saved", isUnlocked = has20PctSaved)
                        BadgeChip("🏆 Goal complete", isUnlocked = hasGoalComplete)
                    }
                }
            }
        }

        // --- Export CSV Report ---
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(text = "📄 Report", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Button(
                        onClick = {
                            val csvData = viewModel.exportCsv()
                            val sendIntent = Intent().apply {
                                action = Intent.ACTION_SEND
                                putExtra(Intent.EXTRA_TEXT, csvData)
                                type = "text/plain"
                            }
                            context.startActivity(Intent.createChooser(sendIntent, "Share Expense CSV"))
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Share CSV Report", color = MaterialTheme.colorScheme.onSurface)
                    }
                }
            }
        }

        item { Spacer(Modifier.height(80.dp)) }
    }
}

@Composable
fun BadgeChip(label: String, isUnlocked: Boolean) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(
                if (isUnlocked) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
                else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
            )
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            fontWeight = if (isUnlocked) FontWeight.Bold else FontWeight.Normal,
            color = if (isUnlocked) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)
        )
    }
}
