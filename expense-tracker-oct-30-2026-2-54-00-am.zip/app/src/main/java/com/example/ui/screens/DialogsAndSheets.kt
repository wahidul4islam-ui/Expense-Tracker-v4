package com.example.ui.screens

import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.TransactionItem
import com.example.data.parser.BanglaUtils
import com.example.data.parser.CategoryRegistry
import com.example.ui.components.TransactionRow
import com.example.ui.theme.ExpenseRed
import com.example.ui.viewmodel.ExpenseViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BazarModeDialog(
    viewModel: ExpenseViewModel,
    onDismiss: () -> Unit
) {
    val bazarItems by viewModel.bazarItems.collectAsState()
    val isBangla = viewModel.prefs.language.collectAsState().value == "bn"
    var currentInput by remember { mutableStateOf("") }

    val speechLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spokenText = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spokenText.isNullOrBlank()) {
                viewModel.addBazarInput(spokenText)
            }
        }
    }

    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
                .testTag("bazar_mode_sheet"),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("🛒 " + BanglaUtils.tr("Bazar mode", isBangla), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close")
                }
            }

            // Voice button
            Box(
                modifier = Modifier.fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                IconButton(
                    onClick = {
                        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
                            putExtra(RecognizerIntent.EXTRA_PROMPT, "Say items, e.g. chal 80, dim 120 taka")
                        }
                        try {
                            speechLauncher.launch(intent)
                        } catch (e: Exception) {
                            viewModel.showToast("Voice input not available on this device")
                        }
                    },
                    modifier = Modifier
                        .size(72.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary)
                ) {
                    Icon(Icons.Default.Mic, contentDescription = "Voice Input", tint = Color.White, modifier = Modifier.size(32.dp))
                }
            }
            Text(
                text = "Tap to speak Bangla/English, or type below.",
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.align(Alignment.CenterHorizontally)
            )

            // Input field
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = currentInput,
                    onValueChange = { currentInput = it },
                    placeholder = { Text("chal 80, dal 120, dim 150…") },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(14.dp)
                )
                IconButton(
                    onClick = {
                        if (currentInput.isNotBlank()) {
                            viewModel.addBazarInput(currentInput)
                            currentInput = ""
                        }
                    },
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary)
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add", tint = Color.White)
                }
            }

            // Items List
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                itemsIndexed(bazarItems) { index, item ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(item.title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(BanglaUtils.formatTaka(item.amount, isBangla), fontWeight = FontWeight.Bold, color = ExpenseRed)
                            IconButton(onClick = { viewModel.removeBazarItem(index) }) {
                                Icon(Icons.Default.Close, contentDescription = "Remove", modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }

            val total = bazarItems.sumOf { it.amount }
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(BanglaUtils.tr("Total", isBangla), fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(BanglaUtils.formatTaka(total, isBangla), fontWeight = FontWeight.Bold, fontSize = 18.sp, color = ExpenseRed)
            }

            Button(
                onClick = { viewModel.saveBazarItems() },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                enabled = bazarItems.isNotEmpty()
            ) {
                Text("Save ${bazarItems.size} items")
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PasteSmsDialog(
    viewModel: ExpenseViewModel,
    onDismiss: () -> Unit
) {
    var smsText by remember { mutableStateOf("") }
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
                .testTag("paste_sms_sheet"),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("📩 Paste SMS", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(
                text = "Paste bKash, Nagad or bank SMS. Separate multiple messages with a blank line.",
                fontSize = 12.5.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            OutlinedTextField(
                value = smsText,
                onValueChange = { smsText = it },
                placeholder = { Text("Paste SMS text here…") },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp),
                shape = RoundedCornerShape(14.dp)
            )

            Button(
                onClick = { viewModel.processPasteSms(smsText) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                enabled = smsText.isNotBlank()
            ) {
                Text("Read SMS")
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReviewParsedSheet(
    items: List<TransactionItem>,
    isBangla: Boolean,
    onSave: () -> Unit,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
                .testTag("review_parsed_sheet"),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "Found ${items.size} ${if (items.size > 1) "entries" else "entry"}",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )

            for (item in items) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val meta = CategoryRegistry.getCategory(item.category)
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(meta.icon, fontSize = 20.sp)
                        Column {
                            Text(item.title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                            Text("${item.category} · ${item.wallet}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    Text(
                        text = (if (item.type == "income") "+" else "−") + BanglaUtils.formatTaka(item.amount, isBangla),
                        fontWeight = FontWeight.Bold,
                        color = if (item.type == "income") com.example.ui.theme.IncomeGreen else ExpenseRed
                    )
                }
            }

            Button(
                onClick = onSave,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text(BanglaUtils.tr("Save", isBangla))
            }

            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(BanglaUtils.tr("Cancel", isBangla), color = MaterialTheme.colorScheme.onSurface)
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditTransactionSheet(
    item: TransactionItem,
    isBangla: Boolean,
    wallets: List<String>,
    onSave: (TransactionItem) -> Unit,
    onDismiss: () -> Unit
) {
    var title by remember { mutableStateOf(item.title) }
    var amount by remember { mutableStateOf(item.amount.toString()) }
    var type by remember { mutableStateOf(item.type) }
    var category by remember { mutableStateOf(item.category) }
    var wallet by remember { mutableStateOf(item.wallet) }
    var note by remember { mutableStateOf(item.note) }
    var imageUri by remember { mutableStateOf(item.imageUri) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            imageUri = uri.toString()
        }
    }

    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
                .testTag("edit_tx_sheet"),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(BanglaUtils.tr("Edit entry", isBangla), fontWeight = FontWeight.Bold, fontSize = 18.sp)

            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text(BanglaUtils.tr("Name", isBangla)) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            OutlinedTextField(
                value = amount,
                onValueChange = { amount = it },
                label = { Text(BanglaUtils.tr("Amount", isBangla)) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            // Type Toggle
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { type = "expense" },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (type == "expense") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
                    ),
                    modifier = Modifier.weight(1f)
                ) {
                    Text(BanglaUtils.tr("Expense", isBangla), color = if (type == "expense") Color.White else MaterialTheme.colorScheme.onSurface)
                }
                Button(
                    onClick = { type = "income" },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (type == "income") MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
                    ),
                    modifier = Modifier.weight(1f)
                ) {
                    Text(BanglaUtils.tr("Income", isBangla), color = if (type == "income") Color.White else MaterialTheme.colorScheme.onSurface)
                }
            }

            // Wallet picker
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                for (w in wallets.take(4)) {
                    Button(
                        onClick = { wallet = w },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (wallet == w) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
                        ),
                        modifier = Modifier.weight(1f),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(4.dp)
                    ) {
                        Text(w, fontSize = 12.sp, color = if (wallet == w) Color.White else MaterialTheme.colorScheme.onSurface)
                    }
                }
            }

            OutlinedTextField(
                value = note,
                onValueChange = { note = it },
                label = { Text("Note or #tag") },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            )

            // Receipt Photo Preview & Picker
            if (!imageUri.isNullOrBlank()) {
                AsyncImage(
                    model = imageUri,
                    contentDescription = "Receipt photo",
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                        .clip(RoundedCornerShape(12.dp))
                )
                Button(
                    onClick = { imageUri = null },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Remove photo", color = ExpenseRed)
                }
            } else {
                Button(
                    onClick = {
                        photoPickerLauncher.launch(
                            androidx.activity.result.PickVisualMediaRequest(
                                ActivityResultContracts.PickVisualMedia.ImageOnly
                            )
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("📎 Add receipt / memo photo", color = MaterialTheme.colorScheme.onSurface)
                }
            }

            Button(
                onClick = {
                    val amt = amount.toDoubleOrNull() ?: item.amount
                    onSave(
                        item.copy(
                            title = title.trim(),
                            amount = amt,
                            type = type,
                            category = category,
                            wallet = wallet,
                            note = note.trim(),
                            imageUri = imageUri
                        )
                    )
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text(BanglaUtils.tr("Save changes", isBangla))
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WalletActionDialog(
    action: String,
    wallets: List<String>,
    isBangla: Boolean,
    viewModel: ExpenseViewModel,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
                .testTag("wallet_action_sheet"),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            when (action) {
                "abl" -> {
                    Text(BanglaUtils.tr("Add balance", isBangla), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    var selectedWallet by remember { mutableStateOf(wallets.firstOrNull() ?: "Cash") }
                    var amount by remember { mutableStateOf("") }

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        for (w in wallets) {
                            Button(
                                onClick = { selectedWallet = w },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (selectedWallet == w) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
                                )
                            ) {
                                Text(w, color = if (selectedWallet == w) Color.White else MaterialTheme.colorScheme.onSurface)
                            }
                        }
                    }

                    OutlinedTextField(
                        value = amount,
                        onValueChange = { amount = it },
                        placeholder = { Text("Amount to add") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Button(
                        onClick = {
                            val amt = amount.toDoubleOrNull() ?: 0.0
                            if (amt > 0) viewModel.addBalanceToWallet(selectedWallet, amt)
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(BanglaUtils.tr("Add", isBangla))
                    }
                }

                "sbl" -> {
                    Text(BanglaUtils.tr("Set balance", isBangla), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    var selectedWallet by remember { mutableStateOf(wallets.firstOrNull() ?: "Cash") }
                    var amount by remember { mutableStateOf("") }

                    Text("Type how much the wallet holds right now.", fontSize = 12.5.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        for (w in wallets) {
                            Button(
                                onClick = { selectedWallet = w },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (selectedWallet == w) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
                                )
                            ) {
                                Text(w, color = if (selectedWallet == w) Color.White else MaterialTheme.colorScheme.onSurface)
                            }
                        }
                    }

                    OutlinedTextField(
                        value = amount,
                        onValueChange = { amount = it },
                        placeholder = { Text("Current balance") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Button(
                        onClick = {
                            val amt = amount.toDoubleOrNull()
                            if (amt != null) viewModel.setWalletBalance(selectedWallet, amt)
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(BanglaUtils.tr("Set balance", isBangla))
                    }
                }

                "wt" -> {
                    Text(BanglaUtils.tr("Transfer", isBangla), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    var fromWallet by remember { mutableStateOf(wallets.firstOrNull() ?: "Cash") }
                    var toWallet by remember { mutableStateOf(wallets.getOrNull(1) ?: "bKash") }
                    var amount by remember { mutableStateOf("") }

                    Text("From wallet:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        for (w in wallets) {
                            Button(
                                onClick = { fromWallet = w },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (fromWallet == w) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
                                )
                            ) {
                                Text(w, color = if (fromWallet == w) Color.White else MaterialTheme.colorScheme.onSurface)
                            }
                        }
                    }

                    Text("To wallet:", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        for (w in wallets) {
                            Button(
                                onClick = { toWallet = w },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (toWallet == w) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
                                )
                            ) {
                                Text(w, color = if (toWallet == w) Color.White else MaterialTheme.colorScheme.onSurface)
                            }
                        }
                    }

                    OutlinedTextField(
                        value = amount,
                        onValueChange = { amount = it },
                        placeholder = { Text("Amount to transfer") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Button(
                        onClick = {
                            val amt = amount.toDoubleOrNull() ?: 0.0
                            if (amt > 0) viewModel.transferBetweenWallets(fromWallet, toWallet, amt)
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(BanglaUtils.tr("Transfer", isBangla))
                    }
                }

                "wa" -> {
                    Text(BanglaUtils.tr("Add wallet", isBangla), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    var newName by remember { mutableStateOf("") }

                    OutlinedTextField(
                        value = newName,
                        onValueChange = { newName = it },
                        placeholder = { Text("Wallet name (e.g. Rocket)") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Button(
                        onClick = {
                            if (newName.isNotBlank()) {
                                viewModel.addNewWallet(newName)
                                newName = ""
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(BanglaUtils.tr("Add wallet", isBangla))
                    }

                    Spacer(Modifier.height(8.dp))
                    Text("Existing wallets:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    for (w in wallets) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(w, fontSize = 14.sp)
                            if (w != "Cash") {
                                IconButton(onClick = { viewModel.deleteWallet(w) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = ExpenseRed)
                                }
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
fun PinLockScreen(
    onUnlock: (String) -> Boolean
) {
    var pinInput by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf("") }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary),
                contentAlignment = Alignment.Center
            ) {
                Text("🔒", fontSize = 28.sp)
            }

            Text(
                text = "Expense Tracker is locked",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )

            OutlinedTextField(
                value = pinInput,
                onValueChange = {
                    pinInput = it
                    errorMessage = ""
                },
                placeholder = { Text("Enter PIN") },
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier
                    .fillMaxWidth(0.7f)
                    .testTag("pin_unlock_field"),
                shape = RoundedCornerShape(14.dp),
                singleLine = true
            )

            if (errorMessage.isNotBlank()) {
                Text(errorMessage, color = ExpenseRed, fontSize = 13.sp)
            }

            Button(
                onClick = {
                    val success = onUnlock(pinInput)
                    if (!success) {
                        errorMessage = "Wrong PIN"
                    }
                },
                modifier = Modifier
                    .fillMaxWidth(0.7f)
                    .testTag("pin_unlock_button"),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text("Unlock")
            }
        }
    }
}
