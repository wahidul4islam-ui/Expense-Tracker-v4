package com.example.data.parser

import androidx.compose.ui.graphics.Color
import com.example.data.model.CategoryMeta

object CategoryRegistry {
    val categories: Map<String, CategoryMeta> = mapOf(
        "Salary" to CategoryMeta(
            name = "Salary",
            icon = "💵",
            colorHex = "#2fa36f",
            keywords = "salary|beton|wage|wages|paycheck|payroll|maine|mahina|বেতন|মাইনে|মাহিনা|মজুরি"
        ),
        "Income" to CategoryMeta(
            name = "Income",
            icon = "💰",
            colorHex = "#5fd3a0",
            keywords = "earn|earned|earning|earnings|income|bonus|freelance|profit|commission|refund|cashback|received|receive|pension|allowance|dividend|sold|sale|bikri|ay|rojgar|উপার্জন|আয়|বোনাস|লাভ|ফেরত|বিক্রি"
        ),
        "Rent" to CategoryMeta(
            name = "Rent",
            icon = "🏠",
            colorHex = "#c77dba",
            keywords = "basha vara|bashavara|basa vara|house rent|room rent|flat rent|service charge|rent|বাসা ভাড়া|বাসাভাড়া|বাড়ি ভাড়া|বাড়িভাড়া"
        ),
        "Utilities" to CategoryMeta(
            name = "Utilities",
            icon = "⚡",
            colorHex = "#e0b43a",
            keywords = "wifi|internet|broadband|electricity|current bill|light bill|gas bill|water bill|gas|wasa|titas|dpdc|desco|nesco|recharge|mobile bill|mobile load|flexiload|data pack|phone bill|bill|current|ওয়াইফাই|ইন্টারনেট|বিদ্যুৎ|কারেন্ট|গ্যাস|বিল|রিচার্জ"
        ),
        "Groceries" to CategoryMeta(
            name = "Groceries",
            icon = "🛒",
            colorHex = "#7fb069",
            keywords = "grocery|groceries|kacha bazar|bazar|bazaar|rice|chal|chaal|atta|flour|moyda|maida|suji|dal|daal|lentil|oil|tel|soybean oil|mustard oil|sugar|chini|salt|lobon|noon|spice|spices|moshla|masala|turmeric|holud|chili|morich|jeera|zira|onion|piyaj|garlic|roshun|ginger|ada|potato|alu|aloo|tomato|begun|brinjal|eggplant|cabbage|cauliflower|fulkopi|bandhakopi|carrot|gajor|cucumber|shosha|pumpkin|kumra|lau|karola|okra|dherosh|spinach|palong|shak|vegetable|vegetables|sobji|shobji|sabji|fish|mach|ilish|hilsa|rui|chicken|murgi|beef|gorur mangsho|mutton|khashi|meat|mangsho|egg|eggs|dim|milk|dudh|doi|yogurt|butter|ghee|cheese|paneer|bread|pauruti|biscuit|noodles|pasta|baby food|cerelac|fruit|fruits|apple|banana|kola|mango|aam|orange|malta|grapes|papaya|pepaya|watermelon|tarmuj|lemon|lebu|coconut|narikel|nuts|dates|khejur|honey|modhu|mineral water|চাল|ডাল|তেল|চিনি|লবণ|নুন|মসলা|পেঁয়াজ|রসুন|আদা|আলু|টমেটো|বেগুন|মাছ|মুরগি|গরুর মাংস|খাসি|মাংস|ডিম|দুধ|দই|ঘি|পাউরুটি|ফল|সবজি|বাজার|কাঁচা বাজার|পটল|ঢ্যাঁড়শ|করলা|উচ্ছে|লাউ|ফুলকপি|বাঁধাকপি|গাজর|শসা|লেবু|আম|কলা|কমলা|তরমুজ|পেঁপে|লিচু|পেয়ারা"
        ),
        "Food" to CategoryMeta(
            name = "Food",
            icon = "🍴",
            colorHex = "#e07a5f",
            keywords = "lunch|dinner|breakfast|nasta|nashta|snacks|snack|chips|biriyani|biryani|khichuri|tehari|kacchi|polao|pulao|paratha|porota|roti|singara|samosa|puri|fuchka|fuska|chotpoti|jhalmuri|burger|pizza|sandwich|shawarma|fried chicken|chowmein|momo|kebab|roll|cake|pastry|sweets|misti|mishti|rasgulla|ice cream|icecream|chocolate|cha|chaa|tea|coffee|juice|lassi|cold drink|coke|pepsi|sprite|soft drink|drinks|cafe|restaurant|hotel food|canteen|tiffin|iftar|sehri|khabar|khawa|food|delivery|foodpanda|লাঞ্চ|ডিনার|নাস্তা|নাশতা|বিরিয়ানি|চা|কফি|খাবার|রেস্টুরেন্ট|ইফতার|সেহরি"
        ),
        "Toiletries" to CategoryMeta(
            name = "Toiletries",
            icon = "🧴",
            colorHex = "#b388eb",
            keywords = "toilet tissue|toilet paper|tissue paper|tissue|wet wipes|wipes|soap|sabun|shampoo|conditioner|body wash|face wash|handwash|hand wash|toothpaste|toothbrush|tooth brush|mouthwash|deodorant|deo|perfume|body spray|lotion|moisturizer|sunscreen|cream|powder|razor|shaving|shave|trimmer|comb|hair oil|sanitary pad|pad|diaper|cotton|nail cutter|lip balm|vaseline|haircut|hair cut|salon|barber|parlour|parlor|facial|spa|massage|সাবান|শ্যাম্পু|টুথপেস্ট|টিস্যু|পাউডার|লোশন|ক্রিম|ডায়াপার|সেলুন|পার্লার"
        ),
        "Household" to CategoryMeta(
            name = "Household",
            icon = "🧽",
            colorHex = "#4fc3f7",
            keywords = "detergent|surf excel|washing powder|vim|dish wash|dishwash|dish soap|harpic|toilet cleaner|floor cleaner|phenyl|bleach|mop|broom|jharu|bucket|mug|bin bag|garbage bag|trash bag|polythene|foil|candle|matchbox|lighter|battery|bulb|tube light|extension|plug|gas cylinder|cylinder|stove|pot|pan|plate|glass|spoon|kitchen|utensils|bedsheet|pillow|blanket|curtain|towel|mosquito coil|mosquito net|mosquito|insect spray|plumber|electrician|mistri|maid|bua|cleaning|laundry|dry clean|ডিটারজেন্ট|ভিম|হারপিক|ঝাড়ু|বালতি|মোমবাতি|ব্যাটারি|বাল্ব|মশারি|কয়েল|তোয়ালে|বুয়া|মিস্ত্রি"
        ),
        "Transport" to CategoryMeta(
            name = "Transport",
            icon = "🚌",
            colorHex = "#6d9eeb",
            keywords = "rickshaw|riksha|rikshaw|bus fare|bus|uber|pathao|obhai|cng|auto|tempo|leguna|taxi|cab|ride|fare|train|launch|ferry|boat|metro rail|metro|bike|motorcycle|petrol|octane|diesel|fuel|parking|toll|ticket|vara|bhara|gari|car wash|mechanic|tyre|রিকশা|বাস|ভাড়া|পেট্রোল|অকটেন|সিএনজি|ট্রেন|লঞ্চ|মেট্রো|পার্কিং|টোল|ট্যাক্সি|উবার|পাঠাও"
        ),
        "Travel" to CategoryMeta(
            name = "Travel",
            icon = "✈️",
            colorHex = "#5c9ce6",
            keywords = "tour|trip|hotel|resort|guest house|flight|air ticket|airfare|visa|passport|booking|cox bazar|sajek|sylhet|bandarban|saint martin|sundarbans|travel|ভ্রমণ|হোটেল"
        ),
        "Shopping" to CategoryMeta(
            name = "Shopping",
            icon = "🛍",
            colorHex = "#f2994a",
            keywords = "shirt|t-shirt|tshirt|pant|jeans|trouser|panjabi|punjabi|saree|sari|salwar|kameez|kurti|three piece|orna|hijab|burqa|burka|lungi|gamcha|jacket|sweater|hoodie|coat|shoes|shoe|sandal|slipper|jutha|boot|sneakers|socks|belt|wallet|bag|backpack|watch|ghori|sunglasses|ring|necklace|jewellery|gold|earring|phone|mobile|smartphone|laptop|tablet|charger|power bank|powerbank|earbuds|earphone|headphone|airpods|cable|mouse|keyboard|monitor|tv|fridge|ac|cooker|rice cooker|blender|oven|furniture|chair|table|sofa|bed|mattress|toy|toys|shopping|jama|kapor|জামা|শার্ট|প্যান্ট|পাঞ্জাবি|শাড়ি|থ্রি পিস|জুতা|স্যান্ডেল|ঘড়ি|ব্যাগ|ফোন|মোবাইল|ল্যাপটপ"
        ),
        "Health" to CategoryMeta(
            name = "Health",
            icon = "💊",
            colorHex = "#e5677d",
            keywords = "medicine|medicines|osudh|osud|tablet|capsule|syrup|napa|paracetamol|antibiotic|vitamin|iron tablet|saline|doctor|dr|consultation|appointment|hospital|clinic|diagnostic|blood test|lab test|xray|x-ray|ultrasound|ecg|dental|dentist|eye test|glasses|specs|lens|surgery|operation|pharmacy|mask|sanitizer|thermometer|insulin|gym|ওষুধ|ঔষধ|ট্যাবলেট|ডাক্তার|হাসপাতাল|ক্লিনিক|ফার্মেসি"
        ),
        "Education" to CategoryMeta(
            name = "Education",
            icon = "📚",
            colorHex = "#ffb74d",
            keywords = "tuition|tution|tuition fee|school|college|university|fees|fee|admission|exam fee|exam|course|class|coaching|book|books|boi|notebook|khata|pen|pencil|stationery|printing|print|photocopy|xerox|uniform|school bag|udemy|coursera|library|বই|খাতা|কলম|পেন্সিল|টিউশন|স্কুল|কলেজ|ভর্তি|ফি|পরীক্ষা|প্রিন্ট|ফটোকপি"
        ),
        "Entertainment" to CategoryMeta(
            name = "Entertainment",
            icon = "🎬",
            colorHex = "#f06292",
            keywords = "movie|cinema|movie ticket|netflix|youtube premium|spotify|hotstar|chorki|prime video|subscription|game|games|gaming|steam|playstation|pubg|free fire|ludo|concert|event ticket|match ticket|party|picnic|park|amusement|outing|hangout|membership|club|sports|কনসার্ট|সিনেমা|মুভি|নেটফ্লিক্স|গেম|পার্টি|পিকনিক|পার্ক"
        ),
        "Gifts" to CategoryMeta(
            name = "Gifts",
            icon = "🎁",
            colorHex = "#ff8a65",
            keywords = "gift|gifts|present|birthday gift|salami|eid salami|zakat|fitra|sadaka|donation|charity|chanda|dan|tip|উপহার|যাকাত|ফিতরা|সদকা|দান|চাঁদা|সালামি"
        ),
        "Debt" to CategoryMeta(
            name = "Debt",
            icon = "🤝",
            colorHex = "#8e7cc3",
            keywords = "debt|loan|borrow|lend|karz|hawlat|ধার|ঋণ|হাওয়ালাত"
        ),
        "Savings" to CategoryMeta(
            name = "Savings",
            icon = "🐷",
            colorHex = "#4db6ac",
            keywords = "savings|saving|joma|sanchay|জমা|সঞ্চয়"
        ),
        "Repair" to CategoryMeta(
            name = "Repair",
            icon = "🛠️",
            colorHex = "#8d99ae",
            keywords = "repair|repairing|marammot|merammot|moramot|mistri|mechanic|mochi|cobbler|shoe repair|juta repair|jutar repair|jutar sole|sole change|sole|sholai|sewing|tailor|darji|alteration|dress repair|jama repair|pant repair|zipper|zip change|chain change|mobile repair|phone repair|screen change|display change|battery change|servicing|mobile servicing|bike servicing|ac servicing|fridge repair|fan repair|cycle repair|rickshaw repair|watch repair|lock repair|key making|puncture|tyre change|plumber|electrician|welding|polish|ironing|মেরামত|সার্ভিসিং|দর্জি"
        ),
        "Other" to CategoryMeta(
            name = "Other",
            icon = "📦",
            colorHex = "#9aa9a2",
            keywords = ""
        )
    )

    fun getCategory(name: String): CategoryMeta {
        return categories[name] ?: categories["Other"]!!
    }

    fun getColor(name: String): Color {
        val meta = getCategory(name)
        return try {
            Color(android.graphics.Color.parseColor(meta.colorHex))
        } catch (e: Exception) {
            Color(0xFF888888)
        }
    }
}
