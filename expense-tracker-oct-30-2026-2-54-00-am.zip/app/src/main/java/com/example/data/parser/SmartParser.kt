package com.example.data.parser

import com.example.data.model.TransactionItem
import java.util.Locale

object SmartParser {

    private val BN_DIGITS = "০১২৩৪৫৬৭৮৯"

    private val WORD_NUMBERS = mapOf(
        "ek" to 1.0, "dui" to 2.0, "tin" to 3.0, "char" to 4.0, "panch" to 5.0,
        "choy" to 6.0, "sat" to 7.0, "aat" to 8.0, "noy" to 9.0, "dosh" to 10.0,
        "egaro" to 11.0, "baro" to 12.0, "tero" to 13.0, "choddo" to 14.0, "ponero" to 15.0,
        "sholo" to 16.0, "satero" to 17.0, "atharo" to 18.0, "unish" to 19.0, "bish" to 20.0,
        "tirish" to 30.0, "challish" to 40.0, "ponchash" to 50.0, "pochash" to 50.0,
        "sath" to 60.0, "shottor" to 70.0, "ashi" to 80.0, "nobboi" to 90.0,
        "এক" to 1.0, "দুই" to 2.0, "তিন" to 3.0, "চার" to 4.0, "পাঁচ" to 5.0,
        "ছয়" to 6.0, "সাত" to 7.0, "আট" to 8.0, "নয়" to 9.0, "দশ" to 10.0,
        "পনেরো" to 15.0, "বিশ" to 20.0, "ত্রিশ" to 30.0, "চল্লিশ" to 40.0, "পঞ্চাশ" to 50.0,
        "der" to 1.5, "dhai" to 2.5, "দেড়" to 1.5, "আড়াই" to 2.5
    )

    private val MULTIPLIERS = mapOf(
        "k" to 1000.0, "hajar" to 1000.0, "hazar" to 1000.0, "হাজার" to 1000.0,
        "lakh" to 100000.0, "lac" to 100000.0, "লাখ" to 100000.0, "লক্ষ" to 100000.0,
        "sho" to 100.0, "শ" to 100.0
    )

    private val UNITS = setOf(
        "kg", "kgs", "kilo", "gm", "gms", "gram", "grams", "g",
        "liter", "litre", "ltr", "l", "ml", "pcs", "pc", "piece",
        "pieces", "pack", "packet", "packets", "dozen", "hali",
        "ta", "ti", "bunch", "box", "bottle", "can", "cup", "sheet",
        "কেজি", "গ্রাম", "লিটার", "পিস", "হালি", "টা", "টি"
    )

    private val FILLERS = setOf(
        "ajke", "aj", "kal", "today", "ke", "korlam", "kinlam", "kinechi",
        "dilam", "diyechi", "dilo", "spent", "paid", "pay", "payment",
        "for", "on", "of", "from", "with", "to", "er", "ar", "a", "an",
        "the", "pelam", "paici", "paisi", "peyechi", "holo", "gelo",
        "got", "get", "gets", "earn", "earned", "earning", "received",
        "receive", "bought", "buy", "purchase", "khoroch", "kharcha",
        "cost", "price", "total", "only", "just", "ei", "ekta", "ekti", "some",
        "আজকে", "আজ", "করলাম", "কিনলাম", "কিনেছি", "দিলাম", "পেলাম", "পেয়েছি", "পাইছি", "পাইলাম", "খরচ"
    )

    private val WALLET_ALIASES = mapOf(
        "বিকাশ" to "bKash",
        "নগদ" to "Nagad",
        "ক্যাশ" to "Cash",
        "b-kash" to "bKash",
        "bkash" to "bKash",
        "nagad" to "Nagad",
        "bank" to "Bank",
        "cash" to "Cash"
    )

    private val INCOME_REGEX = Regex("(^|\\s)(got|get|pelam|paici|paisi|peyechi|earn|income|salary|received|receive|পেলাম|পেয়েছি|পাইছি|পাইলাম|আয়|বেতন)(\\s|\$)")

    fun parseInput(
        input: String,
        availableWallets: List<String> = listOf("Cash", "bKash", "Nagad", "Bank"),
        learnedCategories: Map<String, Pair<String, String>> = emptyMap()
    ): List<TransactionItem> {
        if (input.isBlank()) return emptyList()

        // 1. Normalize Bengali digits
        var text = input
        for (i in BN_DIGITS.indices) {
            text = text.replace(BN_DIGITS[i], '0' + i)
        }

        // Remove commas inside numbers (e.g., 1,000 -> 1000)
        text = text.replace(Regex("(\\d),(?=\\d)"), "$1")
        // Remove currency symbols/words
        text = text.replace(Regex("৳|(?<![a-zA-Z])(?:taka|takar|tk)(?![a-zA-Z])|টাকা", RegexOption.IGNORE_CASE), " ")

        // Split into items by delimiter
        val segments = text.split(Regex("[,;\\n।]|\"|\\s+(?:ar|and|ebong|আর|এবং|&)\\s+", RegexOption.IGNORE_CASE))
        val results = mutableListOf<TransactionItem>()

        for (rawSeg in segments) {
            val seg = rawSeg.trim()
            if (seg.isBlank()) continue

            // Check bracketed wallet e.g. (bkash)
            var chosenWallet = "Cash"
            val bracketMatch = Regex("\\(([^)]*)\\)").find(seg)
            if (bracketMatch != null) {
                val bracketContent = bracketMatch.groupValues[1].trim().lowercase()
                val matched = WALLET_ALIASES[bracketContent] ?: availableWallets.find { it.lowercase() == bracketContent }
                if (matched != null) chosenWallet = matched
            }

            val cleanSeg = seg.replace(Regex("\\([^)]*\\)"), " ").trim()
            val tokens = cleanSeg.split(Regex("\\s+")).filter { it.isNotBlank() }
            if (tokens.isEmpty()) continue

            val tags = tokens.filter { it.startsWith("#") }
            val words = tokens.filter { !it.startsWith("#") }
            if (words.isEmpty()) continue

            // Find amount and used indices
            var amount = 0.0
            val usedIndices = mutableSetOf<Int>()

            for (i in words.indices) {
                val w = words[i].lowercase(Locale.ROOT)
                val isNum = w.matches(Regex("^\\d+(\\.\\d+)?k?\$"))
                val isUnit = (i + 1 < words.size && UNITS.contains(words[i + 1].lowercase())) || (i > 0 && words[i - 1].lowercase() == "x")

                if (isNum && !isUnit) {
                    val m = Regex("^(\\d+(\\.\\d+)?)(k)?\$").find(w)
                    if (m != null) {
                        var parsedVal = m.groupValues[1].toDoubleOrNull() ?: 0.0
                        if (m.groupValues[3] == "k") parsedVal *= 1000.0
                        if (i + 1 < words.size) {
                            val mul = MULTIPLIERS[words[i + 1].lowercase()]
                            if (mul != null) {
                                parsedVal *= mul
                                usedIndices.add(i + 1)
                            }
                        }
                        amount = parsedVal
                        usedIndices.add(i)
                        break
                    }
                }
            }

            // If not found via digits, check word numbers
            if (amount <= 0.0) {
                for (i in words.indices) {
                    val w = words[i].lowercase(Locale.ROOT)
                    val numVal = WORD_NUMBERS[w]
                    if (numVal != null) {
                        var parsedVal = numVal
                        if (i + 1 < words.size) {
                            val mul = MULTIPLIERS[words[i + 1].lowercase()]
                            if (mul != null) {
                                parsedVal *= mul
                                usedIndices.add(i + 1)
                            }
                        }
                        if (parsedVal >= 10.0 || usedIndices.isNotEmpty()) {
                            amount = parsedVal
                            usedIndices.add(i)
                            break
                        }
                    }
                }
            }

            if (amount <= 0.0) continue

            // Collect non-numeric base words for category and title
            val baseWords = words.mapIndexedNotNull { index, word ->
                val lower = word.lowercase()
                val isNum = word.matches(Regex("^\\d+(\\.\\d+)?k?\$"))
                val isUnitAfterNum = index > 0 && UNITS.contains(lower) && words[index - 1].matches(Regex("^\\d+(\\.\\d+)?k?\$"))
                if (index !in usedIndices && !isNum && !isUnitAfterNum) {
                    word
                } else null
            }

            val joinedLower = " " + baseWords.joinToString(" ") { it.lowercase() } + " "

            // Detect category from CategoryRegistry keywords
            var detectedCategory = "Other"
            var bestKeywordLength = 0

            for ((catName, meta) in CategoryRegistry.categories) {
                if (meta.keywords.isBlank()) continue
                val kwList = meta.keywords.split("|")
                for (kw in kwList) {
                    if (kw.isNotBlank() && joinedLower.contains(" $kw ") && kw.length > bestKeywordLength) {
                        detectedCategory = catName
                        bestKeywordLength = kw.length
                    }
                }
            }

            val isIncomeKeyword = INCOME_REGEX.containsMatchIn(joinedLower)
            if (detectedCategory == "Other" && isIncomeKeyword) {
                detectedCategory = "Income"
            }

            var isIncome = detectedCategory == "Salary" || detectedCategory == "Income"

            // Construct title
            val meaningfulWords = baseWords.filter { !FILLERS.contains(it.lowercase()) }.take(5)
            var title = meaningfulWords.joinToString(" ")
            if (detectedCategory == "Salary") {
                title = "Salary"
            } else if (title.isBlank()) {
                title = if (isIncome) "Income" else detectedCategory
            } else {
                title = title.replaceFirstChar { if (it.isLowerCase()) it.titlecase(Locale.ROOT) else it.toString() }
            }

            // Learned categories override
            val learned = learnedCategories[title.lowercase()]
            if (learned != null) {
                detectedCategory = learned.first
                isIncome = learned.second == "income"
            }

            results.add(
                TransactionItem(
                    type = if (isIncome) "income" else "expense",
                    title = title,
                    category = detectedCategory,
                    amount = amount,
                    wallet = chosenWallet,
                    note = tags.joinToString(" "),
                    timestamp = System.currentTimeMillis()
                )
            )
        }

        return results
    }

    /**
     * Parses transactional SMS notifications from mobile financial services
     */
    fun parseSms(smsText: String): List<TransactionItem> {
        val messages = smsText.split(Regex("\\n\\s*\\n"))
        val results = mutableListOf<TransactionItem>()

        for (msg in messages) {
            val trimmed = msg.trim()
            if (trimmed.isBlank()) continue

            val amountMatch = Regex("(?:tk|bdt|৳)\\.?\\s*([\\d,]+(?:\\.\\d+)?)", RegexOption.IGNORE_CASE).find(trimmed)
                ?: continue
            val lower = trimmed.lowercase()

            // Skip cash-in / add money unless received
            if ((lower.contains("cash in") || lower.contains("add money")) && !lower.contains("received")) {
                continue
            }

            val rawAmtStr = amountMatch.groupValues[1].replace(",", "")
            val amount = rawAmtStr.toDoubleOrNull() ?: continue
            if (amount <= 0.0) continue

            val counterpartyMatch = Regex("(?:to|from)\\s+([A-Za-z0-9 .&-]{1,24})", RegexOption.IGNORE_CASE).find(trimmed)
            val counterparty = counterpartyMatch?.groupValues?.get(1)?.trim() ?: ""

            val isIncome = lower.contains("received") || lower.contains("credited") || lower.contains("refund")
            val isCashOut = lower.contains("cash out")

            val title = when {
                isIncome -> if (counterparty.isNotBlank()) "Received from $counterparty" else "Received"
                isCashOut -> "Cash out"
                counterparty.isNotBlank() -> "Paid $counterparty"
                else -> "Payment"
            }

            val wallet = when {
                lower.contains("nagad") -> "Nagad"
                lower.contains("bkash") -> "bKash"
                lower.contains("bank") -> "Bank"
                else -> "Cash"
            }

            results.add(
                TransactionItem(
                    type = if (isIncome) "income" else "expense",
                    title = title,
                    category = if (isIncome) "Income" else "Other",
                    amount = amount,
                    wallet = wallet,
                    note = "SMS import",
                    timestamp = System.currentTimeMillis()
                )
            )
        }

        return results
    }
}
