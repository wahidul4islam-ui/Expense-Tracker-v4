package com.example.data.preferences

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

class UserPreferencesManager(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("hishab_prefs", Context.MODE_PRIVATE)

    private val _userName = MutableStateFlow(prefs.getString(KEY_USER_NAME, "") ?: "")
    val userName: StateFlow<String> = _userName.asStateFlow()

    private val _theme = MutableStateFlow(prefs.getString(KEY_THEME, "system") ?: "system")
    val theme: StateFlow<String> = _theme.asStateFlow()

    private val _accent = MutableStateFlow(prefs.getString(KEY_ACCENT, "green") ?: "green")
    val accent: StateFlow<String> = _accent.asStateFlow()

    private val _language = MutableStateFlow(prefs.getString(KEY_LANG, "en") ?: "en")
    val language: StateFlow<String> = _language.asStateFlow()

    private val _reviewBeforeSave = MutableStateFlow(prefs.getBoolean(KEY_REVIEW, true))
    val reviewBeforeSave: StateFlow<Boolean> = _reviewBeforeSave.asStateFlow()

    private val _pin = MutableStateFlow(prefs.getString(KEY_PIN, "") ?: "")
    val pin: StateFlow<String> = _pin.asStateFlow()

    private val _wallets = MutableStateFlow(loadWallets())
    val wallets: StateFlow<List<String>> = _wallets.asStateFlow()

    private val _walletOffsets = MutableStateFlow(loadWalletOffsets())
    val walletOffsets: StateFlow<Map<String, Double>> = _walletOffsets.asStateFlow()

    private val _savingsRateGoal = MutableStateFlow(prefs.getInt(KEY_SAVINGS_RATE, 0))
    val savingsRateGoal: StateFlow<Int> = _savingsRateGoal.asStateFlow()

    private val _salaryAutoSave = MutableStateFlow(prefs.getInt(KEY_SALARY_AUTO_SAVE, 0))
    val salaryAutoSave: StateFlow<Int> = _salaryAutoSave.asStateFlow()

    private val _challengeCategory = MutableStateFlow(prefs.getString(KEY_CHALLENGE_CAT, "") ?: "")
    val challengeCategory: StateFlow<String> = _challengeCategory.asStateFlow()

    private val _challengeLimit = MutableStateFlow(prefs.getFloat(KEY_CHALLENGE_LIMIT, 0f).toDouble())
    val challengeLimit: StateFlow<Double> = _challengeLimit.asStateFlow()

    private val _challengeMonth = MutableStateFlow(prefs.getString(KEY_CHALLENGE_MONTH, "") ?: "")
    val challengeMonth: StateFlow<String> = _challengeMonth.asStateFlow()

    fun setUserName(name: String) {
        prefs.edit().putString(KEY_USER_NAME, name).apply()
        _userName.value = name
    }

    fun setTheme(theme: String) {
        prefs.edit().putString(KEY_THEME, theme).apply()
        _theme.value = theme
    }

    fun setAccent(accent: String) {
        prefs.edit().putString(KEY_ACCENT, accent).apply()
        _accent.value = accent
    }

    fun setLanguage(lang: String) {
        prefs.edit().putString(KEY_LANG, lang).apply()
        _language.value = lang
    }

    fun setReviewBeforeSave(review: Boolean) {
        prefs.edit().putBoolean(KEY_REVIEW, review).apply()
        _reviewBeforeSave.value = review
    }

    fun setPin(pin: String) {
        prefs.edit().putString(KEY_PIN, pin).apply()
        _pin.value = pin
    }

    fun addWallet(walletName: String) {
        val current = _wallets.value.toMutableList()
        if (!current.contains(walletName)) {
            current.add(walletName)
            saveWallets(current)
            _wallets.value = current
        }
    }

    fun removeWallet(walletName: String) {
        if (walletName == "Cash") return
        val current = _wallets.value.toMutableList()
        current.remove(walletName)
        saveWallets(current)
        _wallets.value = current

        val offsets = _walletOffsets.value.toMutableMap()
        offsets.remove(walletName)
        saveWalletOffsets(offsets)
        _walletOffsets.value = offsets
    }

    fun setWalletOffset(wallet: String, offset: Double) {
        val current = _walletOffsets.value.toMutableMap()
        current[wallet] = offset
        saveWalletOffsets(current)
        _walletOffsets.value = current
    }

    fun addWalletOffset(wallet: String, delta: Double) {
        val current = _walletOffsets.value.toMutableMap()
        val prev = current[wallet] ?: 0.0
        current[wallet] = prev + delta
        saveWalletOffsets(current)
        _walletOffsets.value = current
    }

    fun setSavingsRateGoal(percent: Int) {
        prefs.edit().putInt(KEY_SAVINGS_RATE, percent).apply()
        _savingsRateGoal.value = percent
    }

    fun setSalaryAutoSave(percent: Int) {
        prefs.edit().putInt(KEY_SALARY_AUTO_SAVE, percent).apply()
        _salaryAutoSave.value = percent
    }

    fun setChallenge(category: String, limit: Double, month: String) {
        prefs.edit()
            .putString(KEY_CHALLENGE_CAT, category)
            .putFloat(KEY_CHALLENGE_LIMIT, limit.toFloat())
            .putString(KEY_CHALLENGE_MONTH, month)
            .apply()
        _challengeCategory.value = category
        _challengeLimit.value = limit
        _challengeMonth.value = month
    }

    fun getLearnedCategories(): Map<String, Pair<String, String>> {
        val raw = prefs.getString(KEY_LEARNED, "{}") ?: "{}"
        val map = mutableMapOf<String, Pair<String, String>>()
        try {
            val json = JSONObject(raw)
            val keys = json.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                val obj = json.getJSONObject(key)
                val cat = obj.optString("c", "Other")
                val type = obj.optString("t", "expense")
                map[key] = Pair(cat, type)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return map
    }

    fun saveLearnedCategory(title: String, category: String, type: String) {
        val current = getLearnedCategories().toMutableMap()
        current[title.lowercase()] = Pair(category, type)
        val json = JSONObject()
        for ((k, v) in current) {
            val obj = JSONObject()
            obj.put("c", v.first)
            obj.put("t", v.second)
            json.put(k, obj)
        }
        prefs.edit().putString(KEY_LEARNED, json.toString()).apply()
    }

    fun clearLearnedCategories() {
        prefs.edit().remove(KEY_LEARNED).apply()
    }

    fun clearAllPreferences() {
        prefs.edit().clear().apply()
        _userName.value = ""
        _theme.value = "system"
        _accent.value = "green"
        _language.value = "en"
        _reviewBeforeSave.value = true
        _pin.value = ""
        _wallets.value = listOf("Cash", "bKash", "Nagad", "Bank")
        _walletOffsets.value = emptyMap()
        _savingsRateGoal.value = 0
        _salaryAutoSave.value = 0
        _challengeCategory.value = ""
        _challengeLimit.value = 0.0
        _challengeMonth.value = ""
    }

    private fun loadWallets(): List<String> {
        val raw = prefs.getString(KEY_WALLETS, null) ?: return listOf("Cash", "bKash", "Nagad", "Bank")
        return try {
            val array = JSONArray(raw)
            val list = mutableListOf<String>()
            for (i in 0 until array.length()) {
                list.add(array.getString(i))
            }
            if (!list.contains("Cash")) list.add(0, "Cash")
            list
        } catch (e: Exception) {
            listOf("Cash", "bKash", "Nagad", "Bank")
        }
    }

    private fun saveWallets(wallets: List<String>) {
        val array = JSONArray()
        for (w in wallets) array.put(w)
        prefs.edit().putString(KEY_WALLETS, array.toString()).apply()
    }

    private fun loadWalletOffsets(): Map<String, Double> {
        val raw = prefs.getString(KEY_WALLET_OFFSETS, "{}") ?: "{}"
        val map = mutableMapOf<String, Double>()
        try {
            val json = JSONObject(raw)
            val keys = json.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                map[key] = json.getDouble(key)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return map
    }

    private fun saveWalletOffsets(offsets: Map<String, Double>) {
        val json = JSONObject()
        for ((k, v) in offsets) {
            json.put(k, v)
        }
        prefs.edit().putString(KEY_WALLET_OFFSETS, json.toString()).apply()
    }

    companion object {
        private const val KEY_USER_NAME = "user_name"
        private const val KEY_THEME = "app_theme"
        private const val KEY_ACCENT = "accent_color"
        private const val KEY_LANG = "language"
        private const val KEY_REVIEW = "review_before_save"
        private const val KEY_PIN = "pin_lock"
        private const val KEY_WALLETS = "wallets_list"
        private const val KEY_WALLET_OFFSETS = "wallet_offsets"
        private const val KEY_SAVINGS_RATE = "savings_rate_goal"
        private const val KEY_SALARY_AUTO_SAVE = "salary_auto_save"
        private const val KEY_CHALLENGE_CAT = "challenge_category"
        private const val KEY_CHALLENGE_LIMIT = "challenge_limit"
        private const val KEY_CHALLENGE_MONTH = "challenge_month"
        private const val KEY_LEARNED = "learned_items"
    }
}
