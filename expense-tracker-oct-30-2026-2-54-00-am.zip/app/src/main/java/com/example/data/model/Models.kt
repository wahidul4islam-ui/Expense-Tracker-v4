package com.example.data.model

enum class ExpenseCategory(
    val categoryName: String,
    val icon: String,
    val colorHex: String
) {
    FOOD("Food", "🍴", "#e07a5f"),
    TRANSPORT("Transport", "🚌", "#6d9eeb"),
    RENT("Rent", "🏠", "#c77dba"),
    GROCERIES("Groceries", "🛒", "#7fb069"),
    UTILITIES("Utilities", "⚡", "#e0b43a"),
    SHOPPING("Shopping", "🛍", "#f2994a"),
    HEALTH("Health", "💊", "#e5677d"),
    EDUCATION("Education", "📚", "#ffb74d"),
    ENTERTAINMENT("Entertainment", "🎬", "#f06292"),
    TRAVEL("Travel", "✈️", "#5c9ce6"),
    HOUSEHOLD("Household", "🧽", "#4fc3f7"),
    TOILETRIES("Toiletries", "🧴", "#b388eb"),
    GIFTS("Gifts", "🎁", "#ff8a65"),
    REPAIR("Repair", "🛠️", "#8d99ae"),
    DEBT("Debt", "🤝", "#8e7cc3"),
    SAVINGS("Savings", "🐷", "#4db6ac"),
    SALARY("Salary", "💵", "#2fa36f"),
    INCOME("Income", "💰", "#5fd3a0"),
    OTHER("Other", "📦", "#9aa9a2");

    companion object {
        fun fromString(name: String?): ExpenseCategory {
            if (name == null) return OTHER
            val normalized = name.trim().lowercase()
            return entries.find { it.categoryName.lowercase() == normalized } ?: OTHER
        }

        fun canonicalNames(): List<String> = entries.map { it.categoryName }
    }
}

data class TransactionItem(
    val id: Long = System.currentTimeMillis(),
    val type: String, // "income" or "expense"
    val title: String,
    val category: String,
    val amount: Double,
    val wallet: String = "Cash",
    val timestamp: Long = System.currentTimeMillis(),
    val note: String = "",
    val imageUri: String? = null,
    val isSalarySaved: Boolean = false
) {
    val expenseCategory: ExpenseCategory
        get() = ExpenseCategory.fromString(category)
}

data class FixedBill(
    val id: Long = System.currentTimeMillis(),
    val title: String,
    val amount: Double,
    val day: Int = 1,
    val category: String = "Utilities",
    val type: String = "expense", // "expense" or "income"
    val paidMonth: String? = null // e.g. "2026-9"
)

data class DebtItem(
    val id: Long = System.currentTimeMillis(),
    val who: String,
    val total: Double,
    val direction: String, // "b" = I borrowed (I owe), "l" = I lent (owes me)
    val date: String,
    val payments: List<DebtPayment> = emptyList()
)

data class DebtPayment(
    val amount: Double,
    val date: String
)

data class SavingsGoal(
    val id: Long = System.currentTimeMillis(),
    val title: String,
    val target: Double,
    val payments: List<DebtPayment> = emptyList()
)

data class CategoryBudget(
    val category: String,
    val limitAmount: Double
)

data class TourItem(
    val id: Long = System.currentTimeMillis(),
    val name: String,
    val budget: Double = 0.0,
    val people: List<String> = listOf("Me"),
    val expenses: List<TourExpense> = emptyList(),
    val addedToBalance: Double = 0.0
)

data class TourExpense(
    val id: Long = System.currentTimeMillis(),
    val title: String,
    val category: String, // Transport, Stay, Food, Shopping, Other
    val amount: Double,
    val paidBy: String,
    val date: String
)

data class WalletTransfer(
    val id: Long = System.currentTimeMillis(),
    val from: String,
    val to: String,
    val amount: Double,
    val timestamp: Long = System.currentTimeMillis()
)

data class WalletHistory(
    val id: Long = System.currentTimeMillis(),
    val timestamp: Long = System.currentTimeMillis(),
    val kind: String, // "add", "set", "transfer"
    val wallet: String,
    val targetWallet: String? = null,
    val amount: Double,
    val prevBalance: Double? = null
)

data class CategoryMeta(
    val name: String,
    val icon: String,
    val colorHex: String,
    val keywords: String
)
