package com.example.data.ai

import android.util.Log
import com.example.data.model.ExpenseCategory
import com.example.data.model.TransactionItem
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.withTimeout
import org.json.JSONObject

private const val TAG = "GeminiExpenseParser"

class GeminiExpenseParserService {

    // Define strict JSON schema using Schema.obj as mandated by Firebase AI Logic
    private val expenseItemSchema = Schema.obj(
        properties = mapOf(
            "title" to Schema.string("Clear, capitalized title of the transaction item, e.g. Lunch, Uber ride, House rent, Electricity bill"),
            "amount" to Schema.double("Numeric amount in Bangladeshi Taka (৳)"),
            "type" to Schema.string("Transaction type: must be either 'expense' or 'income'"),
            "category" to Schema.string(
                "Categorize accurately into one of the canonical categories: Food, Transport, Rent, Groceries, Utilities, Shopping, Health, Education, Entertainment, Travel, Household, Toiletries, Gifts, Repair, Debt, Savings, Salary, Income, Other"
            ),
            "wallet" to Schema.string("Payment wallet or account: Cash, bKash, Nagad, Bank, or specified wallet name"),
            "note" to Schema.string("Any extra context, note or hashtag (e.g. #office, #weekend)")
        ),
        optionalProperties = listOf("note")
    )

    private val responseSchema = Schema.obj(
        properties = mapOf(
            "items" to Schema.array(
                items = expenseItemSchema,
                description = "Array of parsed transactions from user natural language input"
            )
        )
    )

    private val config = generationConfig {
        responseMimeType = "application/json"
        this.responseSchema = this@GeminiExpenseParserService.responseSchema
    }

    // Lazy initialization of Gemini model to prevent early class loading issues
    private val model by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = config
        )
    }

    /**
     * Parses natural language input in Bangla, English, or Banglish into structured TransactionItems,
     * automatically categorizing items into canonical categories like Food, Transport, Rent, etc.
     */
    suspend fun parseExpenseInput(
        input: String,
        availableWallets: List<String> = listOf("Cash", "bKash", "Nagad", "Bank")
    ): Result<List<TransactionItem>> {
        if (input.isBlank()) {
            return Result.success(emptyList())
        }

        val walletsStr = availableWallets.joinToString(", ")
        val categoriesStr = ExpenseCategory.canonicalNames().joinToString(", ")

        val prompt = """
            You are an expert bilingual Bangladeshi financial expense logging and categorization assistant.
            Parse the following user input into structured financial transactions and automatically categorize every expense.
            The user may input text in English, Bangla script (বাংলা), or Banglish (Bangla in Latin letters).

            ### CATEGORIZATION RULES (Assign one of: $categoriesStr):
            1. 'Food': Prepared meals, restaurant dining, cafe, snacks, tea/cha, coffee, lunch, dinner, breakfast, takeout, fast food, bakery, sweets, foodpanda.
               - Examples: 'lunch 250', 'cha biscuit 40', 'dinner with friends 600', 'kacchi biryani 350', 'burger 180', 'nasta 50'
            2. 'Transport': Daily commute, rickshaw/riksha/রিকশা, bus fare/বাস, metro rail/মেট্রো, CNG auto, Uber/Pathao rides, train, ferry, bike fuel, petrol, toll, parking.
               - Examples: 'rickshaw 60', 'uber ride 320 to office', 'bus fare 30', 'metro rail 40', 'bike petrol 500'
            3. 'Rent': House rent (basha vara/বাসাভাড়া/বাসা ভাড়া), apartment rent, room rent, flat rent, office rent, hostel rent, building service charge.
               - Examples: 'basha vara 16000', 'room rent 5000', 'flat rent 22000 (bank)', 'house rent 18k'
            4. 'Groceries': Raw cooking ingredients, bazaar shopping (kacha bazar/কাঁচা বাজার), vegetables, rice/chal, lentils/dal, cooking oil, fish, chicken, beef/meat, eggs, milk, fruits.
               - Examples: 'kacha bazar 850', 'chal 80 taka', 'dim 140', 'sobji 120'
            5. 'Utilities': WiFi/internet bill, electricity/current bill, gas bill, water (WASA), mobile recharge, data pack, phone bill.
               - Examples: 'wifi bill 500', 'current bill 1400', 'recharge 100 (bkash)'
            6. 'Shopping': Clothes, shirts, pants, shoes, sandals, electronics, gadgets, watches, cosmetics, appliances.
            7. 'Health': Medicines (osudh/ওষুধ), doctor fees, diagnostic tests, clinic, pharmacy.
            8. 'Education': School/college tuition fees, coaching, books, exam fee, stationery.
            9. 'Entertainment': Cinema, movie tickets, streaming (Netflix, Spotify), gaming, concerts.
            10. 'Travel': Outstation tour, hotel stay, flight tickets, resort booking.
            11. 'Household': Detergent, cleaning supplies, broom, repairs, kitchen utensils, toiletries.
            12. 'Salary' & 'Income': Monthly salary (beton/বেতন), wage, freelance payment, bonus, sales profit.

            ### NUMBER & CURRENCY HANDLING:
            - Understand Bangladeshi Taka (৳, tk, taka, টাকা).
            - Support multipliers: 'k' = 1,000 (e.g. 80k = 80000), 'hajar'/'hazar'/'হাজার' = 1,000, 'lakh'/'lac'/'লাখ' = 100,000.
            - Support Bengali numerals (০-৯) (e.g. ২৫০ = 250).
            - Determine wallet: match indicated wallet or bracket like '(bkash)', '(nagad)', '(bank)'. Available: $walletsStr. Default to 'Cash' if unspecified.
            - Determine type: 'expense' or 'income'.

            User Input: "$input"
        """.trimIndent()

        return try {
            val response = withTimeout(60_000L) {
                model.generateContent(prompt)
            }

            val jsonText = response.text
            if (jsonText.isNullOrBlank()) {
                return Result.failure(IllegalStateException("Gemini returned empty response."))
            }

            Log.d(TAG, "Gemini JSON response: $jsonText")

            val rootObj = JSONObject(jsonText)
            val itemsArray = rootObj.optJSONArray("items")
            val results = mutableListOf<TransactionItem>()

            if (itemsArray != null) {
                for (i in 0 until itemsArray.length()) {
                    val obj = itemsArray.getJSONObject(i)
                    val title = obj.optString("title", "Expense")
                    val amount = obj.optDouble("amount", 0.0)
                    val type = obj.optString("type", "expense").lowercase()
                    val rawCategory = obj.optString("category", "Other")
                    val wallet = obj.optString("wallet", "Cash")
                    val note = obj.optString("note", "")

                    // Strictly normalize into canonical category
                    val canonicalCategory = ExpenseCategory.fromString(rawCategory).categoryName

                    if (amount > 0.0) {
                        results.add(
                            TransactionItem(
                                id = System.currentTimeMillis() + i,
                                type = if (type == "income") "income" else "expense",
                                title = title.replaceFirstChar { it.uppercase() },
                                category = canonicalCategory,
                                amount = amount,
                                wallet = if (availableWallets.contains(wallet)) wallet else "Cash",
                                timestamp = System.currentTimeMillis() - i,
                                note = note
                            )
                        )
                    }
                }
            }

            Result.success(results)
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Gemini parsing timed out", e)
            Result.failure(e)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Gemini parsing failed", e)
            Result.failure(e)
        }
    }
}
