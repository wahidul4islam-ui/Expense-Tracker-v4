package com.example.data.parser

import java.text.NumberFormat
import java.util.Locale

object BanglaUtils {

    private val BN_DIGITS = listOf('০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯')

    fun formatTaka(amount: Double, isBangla: Boolean = false): String {
        val rounded = Math.round(Math.abs(amount))
        // Format with commas according to South Asian format (en_IN)
        val formatted = try {
            val nf = NumberFormat.getNumberInstance(Locale("en", "IN"))
            nf.format(rounded)
        } catch (e: Exception) {
            rounded.toString()
        }
        val result = "৳$formatted"
        return if (isBangla) toBanglaDigits(result) else result
    }

    fun formatSignedTaka(type: String, amount: Double, isBangla: Boolean = false): String {
        val sign = if (type == "income") "+" else "−"
        return sign + formatTaka(amount, isBangla)
    }

    fun formatShortTaka(amount: Double, isBangla: Boolean = false): String {
        val absVal = Math.abs(amount)
        val text = when {
            absVal >= 100000 -> {
                val lakh = absVal / 100000.0
                String.format(Locale.ROOT, "%.1f L", lakh).replace(".0", "")
            }
            absVal >= 1000 -> {
                val k = Math.round(absVal / 1000.0)
                "${k}k"
            }
            else -> Math.round(absVal).toString()
        }
        val result = "৳$text"
        return if (isBangla) toBanglaDigits(result) else result
    }

    fun toBanglaDigits(input: String): String {
        val sb = StringBuilder()
        for (char in input) {
            if (char in '0'..'9') {
                sb.append(BN_DIGITS[char - '0'])
            } else {
                sb.append(char)
            }
        }
        return sb.toString()
    }

    private val DICTIONARY = mapOf(
        "Manage wallets" to "ওয়ালেট পরিচালনা",
        "Tap For Balance" to "ব্যালেন্স দেখুন",
        "Add balance" to "ব্যালেন্স যোগ",
        "Set balance" to "ব্যালেন্স সেট",
        "Home" to "হোম",
        "Wallets" to "ওয়ালেট",
        "History" to "ইতিহাস",
        "Plan" to "পরিকল্পনা",
        "Insights" to "ইনসাইট",
        "Settings" to "সেটিংস",
        "Balance" to "ব্যালেন্স",
        "this month" to "এই মাস",
        "Today" to "আজ",
        "Recent" to "সাম্প্রতিক",
        "See all" to "সব দেখুন",
        "Bazar mode" to "বাজার মোড",
        "Paste SMS" to "এসএমএস পেস্ট",
        "Monthly fixed" to "মাসিক নির্ধারিত",
        "unpaid" to "বাকি",
        "Pay" to "পরিশোধ",
        "Got it" to "পেয়েছি",
        "Budget alert" to "বাজেট সতর্কতা",
        "used" to "ব্যবহৃত",
        "All" to "সব",
        "Income" to "আয়",
        "Expenses" to "খরচ",
        "Expense" to "খরচ",
        "Search entries" to "অনুসন্ধান করুন",
        "Filters" to "ফিল্টার",
        "Amount" to "পরিমাণ",
        "Min" to "সর্বনিম্ন",
        "Max" to "সর্বোচ্চ",
        "Date range" to "তারিখের সীমা",
        "Custom range" to "নির্দিষ্ট সময়",
        "Clear filters" to "ফিল্টার মুছুন",
        "net" to "নিট",
        "Saved" to "সঞ্চয়",
        "saved" to "সেভ হয়েছে",
        "Month" to "মাস",
        "6 months" to "৬ মাস",
        "This year" to "এ বছর",
        "Monthly trend" to "মাসিক ট্রেন্ড",
        "By category" to "ক্যাটাগরি অনুযায়ী",
        "Spent" to "খরচ",
        "Earned" to "আয়",
        "Total" to "মোট",
        "Peak" to "সর্বোচ্চ",
        "vs last month" to "গত মাসের তুলনায়",
        "Debt" to "ঋণ",
        "Savings" to "সঞ্চয়",
        "Monthly" to "মাসিক",
        "Budget" to "বাজেট",
        "Tour" to "ভ্রমণ",
        "I owe" to "আমি দেব",
        "Owed to me" to "আমি পাব",
        "Owes me" to "আমাকে দেবে",
        "New debt" to "নতুন ঋণ",
        "Add payment" to "পেমেন্ট যোগ",
        "Delete" to "মুছুন",
        "Name" to "নাম",
        "Add" to "যোগ",
        "left" to "বাকি",
        "Cleared" to "পরিশোধিত",
        "Total saved" to "মোট সঞ্চয়",
        "New goal" to "নতুন লক্ষ্য",
        "Save money" to "টাকা জমান",
        "Add goal" to "লক্ষ্য যোগ",
        "Profile" to "প্রোফাইল",
        "Save name" to "নাম সংরক্ষণ",
        "Your name" to "আপনার নাম",
        "Appearance" to "চেহারা",
        "System" to "সিস্টেম",
        "Light" to "লাইট",
        "Dark" to "ডার্ক",
        "Accent color" to "অ্যাকসেন্ট রং",
        "Currency" to "মুদ্রা",
        "Bangladeshi Taka" to "বাংলাদেশি টাকা",
        "Cash" to "ক্যাশ",
        "Bank" to "ব্যাংক",
        "Add wallet" to "ওয়ালেট যোগ",
        "Transfer" to "ট্রান্সফার",
        "Smart entry" to "স্মার্ট এন্ট্রি",
        "Review before saving" to "সেভের আগে দেখুন",
        "Learned items" to "শেখা আইটেম",
        "Forget" to "মুছে ফেলুন",
        "Your data" to "আপনার ডেটা",
        "Copy CSV" to "CSV কপি",
        "Import CSV" to "CSV ইম্পোর্ট",
        "Copy full backup" to "পূর্ণ ব্যাকআপ কপি",
        "Restore from backup" to "ব্যাকআপ থেকে রিস্টোর",
        "Delete all data" to "সব ডেটা মুছুন",
        "Undo" to "আগের অবস্থা",
        "Save" to "সেভ",
        "Cancel" to "বাতিল",
        "Edit entry" to "এন্ট্রি এডিট",
        "Save changes" to "পরিবর্তন সেভ",
        "Found" to "পাওয়া গেছে",
        "entries" to "এন্ট্রি",
        "entry" to "এন্ট্রি",
        "Deleted" to "মুছে ফেলা হয়েছে",
        "Restored" to "ফিরিয়ে আনা হয়েছে",
        "Updated" to "আপডেট হয়েছে",
        "Import" to "ইম্পোর্ট",
        "Salary" to "বেতন",
        "Rent" to "ভাড়া",
        "Utilities" to "ইউটিলিটি",
        "Groceries" to "মুদি",
        "Food" to "খাবার",
        "Toiletries" to "প্রসাধনী",
        "Household" to "গৃহস্থালি",
        "Transport" to "যাতায়াত",
        "Travel" to "ভ্রমণ",
        "Shopping" to "শপিং",
        "Health" to "স্বাস্থ্য",
        "Education" to "শিক্ষা",
        "Entertainment" to "বিনোদন",
        "Gifts" to "উপহার",
        "Other" to "অন্যান্য",
        "Repair" to "মেরামত",
        "Settle up" to "হিসাব মেটান",
        "All settled" to "সব মেটানো",
        "each" to "জনপ্রতি",
        "people" to "জন",
        "Create tour" to "ট্যুর তৈরি",
        "Add expenses" to "খরচ যোগ",
        "All tours" to "সব ভ্রমণ"
    )

    fun tr(key: String, isBangla: Boolean): String {
        if (!isBangla) return key
        return DICTIONARY[key] ?: key
    }
}
