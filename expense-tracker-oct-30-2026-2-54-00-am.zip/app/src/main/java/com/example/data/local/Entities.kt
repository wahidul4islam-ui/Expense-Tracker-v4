package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey val id: Long,
    val type: String,
    val title: String,
    val category: String,
    val amount: Double,
    val wallet: String,
    val timestamp: Long,
    val note: String,
    val imageUri: String?,
    val isSalarySaved: Boolean
)

@Entity(tableName = "fixed_bills")
data class FixedBillEntity(
    @PrimaryKey val id: Long,
    val title: String,
    val amount: Double,
    val day: Int,
    val category: String,
    val type: String,
    val paidMonth: String?
)

@Entity(tableName = "debts")
data class DebtEntity(
    @PrimaryKey val id: Long,
    val who: String,
    val total: Double,
    val direction: String,
    val date: String,
    val paymentsJson: String
)

@Entity(tableName = "savings_goals")
data class SavingsGoalEntity(
    @PrimaryKey val id: Long,
    val title: String,
    val target: Double,
    val paymentsJson: String
)

@Entity(tableName = "budgets")
data class BudgetEntity(
    @PrimaryKey val category: String,
    val limitAmount: Double
)

@Entity(tableName = "tours")
data class TourEntity(
    @PrimaryKey val id: Long,
    val name: String,
    val budget: Double,
    val peopleJson: String,
    val expensesJson: String,
    val addedToBalance: Double
)

@Entity(tableName = "wallet_history")
data class WalletHistoryEntity(
    @PrimaryKey val id: Long,
    val timestamp: Long,
    val kind: String,
    val wallet: String,
    val targetWallet: String?,
    val amount: Double,
    val prevBalance: Double?
)
