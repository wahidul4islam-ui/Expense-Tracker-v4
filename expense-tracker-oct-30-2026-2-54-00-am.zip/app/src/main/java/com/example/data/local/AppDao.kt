package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface AppDao {
    // Transactions
    @Query("SELECT * FROM transactions ORDER BY timestamp DESC")
    fun getAllTransactions(): Flow<List<TransactionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: TransactionEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransactions(transactions: List<TransactionEntity>)

    @Update
    suspend fun updateTransaction(transaction: TransactionEntity)

    @Query("DELETE FROM transactions WHERE id = :id")
    suspend fun deleteTransaction(id: Long)

    @Query("DELETE FROM transactions")
    suspend fun clearAllTransactions()

    // Fixed Bills
    @Query("SELECT * FROM fixed_bills")
    fun getAllFixedBills(): Flow<List<FixedBillEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFixedBill(bill: FixedBillEntity)

    @Update
    suspend fun updateFixedBill(bill: FixedBillEntity)

    @Query("DELETE FROM fixed_bills WHERE id = :id")
    suspend fun deleteFixedBill(id: Long)

    @Query("DELETE FROM fixed_bills")
    suspend fun clearAllFixedBills()

    // Debts
    @Query("SELECT * FROM debts ORDER BY id DESC")
    fun getAllDebts(): Flow<List<DebtEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDebt(debt: DebtEntity)

    @Update
    suspend fun updateDebt(debt: DebtEntity)

    @Query("DELETE FROM debts WHERE id = :id")
    suspend fun deleteDebt(id: Long)

    @Query("DELETE FROM debts")
    suspend fun clearAllDebts()

    // Savings Goals
    @Query("SELECT * FROM savings_goals ORDER BY id DESC")
    fun getAllSavingsGoals(): Flow<List<SavingsGoalEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSavingsGoal(goal: SavingsGoalEntity)

    @Update
    suspend fun updateSavingsGoal(goal: SavingsGoalEntity)

    @Query("DELETE FROM savings_goals WHERE id = :id")
    suspend fun deleteSavingsGoal(id: Long)

    @Query("DELETE FROM savings_goals")
    suspend fun clearAllSavingsGoals()

    // Budgets
    @Query("SELECT * FROM budgets")
    fun getAllBudgets(): Flow<List<BudgetEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBudget(budget: BudgetEntity)

    @Query("DELETE FROM budgets WHERE category = :category")
    suspend fun deleteBudget(category: String)

    @Query("DELETE FROM budgets")
    suspend fun clearAllBudgets()

    // Tours
    @Query("SELECT * FROM tours ORDER BY id DESC")
    fun getAllTours(): Flow<List<TourEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTour(tour: TourEntity)

    @Update
    suspend fun updateTour(tour: TourEntity)

    @Query("DELETE FROM tours WHERE id = :id")
    suspend fun deleteTour(id: Long)

    @Query("DELETE FROM tours")
    suspend fun clearAllTours()

    // Wallet History
    @Query("SELECT * FROM wallet_history ORDER BY timestamp DESC LIMIT 100")
    fun getWalletHistory(): Flow<List<WalletHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWalletHistory(item: WalletHistoryEntity)

    @Query("DELETE FROM wallet_history")
    suspend fun clearAllWalletHistory()
}
