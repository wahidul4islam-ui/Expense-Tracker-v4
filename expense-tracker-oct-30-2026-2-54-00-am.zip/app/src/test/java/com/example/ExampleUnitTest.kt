package com.example

import com.example.data.parser.BanglaUtils
import com.example.data.parser.SmartParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun testSimpleExpenseParsing() {
        val parsed = SmartParser.parseInput("lunch 250")
        assertEquals(1, parsed.size)
        assertEquals(250.0, parsed[0].amount, 0.001)
        assertEquals("expense", parsed[0].type)
        assertEquals("Food", parsed[0].category)
    }

    @Test
    fun testMultiItemBanglaWithWallet() {
        val parsed = SmartParser.parseInput("chal 80 taka (bkash), dal 120, wifi bill 500 (bank)")
        assertEquals(3, parsed.size)
        assertEquals("bKash", parsed[0].wallet)
        assertEquals("Groceries", parsed[0].category)
        assertEquals(80.0, parsed[0].amount, 0.001)

        assertEquals("Cash", parsed[1].wallet)
        assertEquals("Groceries", parsed[1].category)
        assertEquals(120.0, parsed[1].amount, 0.001)

        assertEquals("Bank", parsed[2].wallet)
        assertEquals("Utilities", parsed[2].category)
        assertEquals(500.0, parsed[2].amount, 0.001)
    }

    @Test
    fun testBengaliDigitsAndSalary() {
        val parsed = SmartParser.parseInput("salary pelam ৮০k")
        assertEquals(1, parsed.size)
        assertEquals(80000.0, parsed[0].amount, 0.001)
        assertEquals("income", parsed[0].type)
        assertEquals("Salary", parsed[0].category)
    }

    @Test
    fun testTakaFormatting() {
        assertEquals("৳250", BanglaUtils.formatTaka(250.0, isBangla = false))
        assertEquals("৳২৫০", BanglaUtils.formatTaka(250.0, isBangla = true))
    }

    @Test
    fun testExpenseCategoryModel() {
        assertEquals(com.example.data.model.ExpenseCategory.FOOD, com.example.data.model.ExpenseCategory.fromString("Food"))
        assertEquals(com.example.data.model.ExpenseCategory.TRANSPORT, com.example.data.model.ExpenseCategory.fromString("transport"))
        assertEquals(com.example.data.model.ExpenseCategory.RENT, com.example.data.model.ExpenseCategory.fromString("Rent"))
        assertEquals(com.example.data.model.ExpenseCategory.GROCERIES, com.example.data.model.ExpenseCategory.fromString("Groceries"))
        assertEquals(com.example.data.model.ExpenseCategory.UTILITIES, com.example.data.model.ExpenseCategory.fromString("Utilities"))
        assertEquals(com.example.data.model.ExpenseCategory.OTHER, com.example.data.model.ExpenseCategory.fromString("UnknownCategory"))
    }

    @Test
    fun testAutomaticCategorizationFoodTransportRent() {
        val food = SmartParser.parseInput("dinner 450")
        assertEquals("Food", food[0].category)

        val transport = SmartParser.parseInput("rickshaw 60")
        assertEquals("Transport", transport[0].category)

        val rent = SmartParser.parseInput("basha vara 15000")
        assertEquals("Rent", rent[0].category)
    }
}
